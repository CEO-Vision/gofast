function PbButtonCtrl($scope) {
  "use strict";

  this.action = function action() {
    document
      .querySelector("[data-id='digitalsign_signing_iframe']")
      .setAttribute("src", $scope.properties.requestUrl + "?type=update&signreqid=" + $scope.properties.requestId);
    document.querySelector("[data-id='digitalsign_signing_iframe']").style.display =
      "block";
    document.querySelector(".btn-danger").style.display = "none";
  };
}
