(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customGofastAutocomplete', function() {
    return {
      controllerAs: 'ctrl',
      controller: function CustomGofastAutocompleteCtrl($scope, $parse, $log, widgetNameFactory, $http) {
  $scope.loading = false;
  
  this.getData = function () {
    $scope.loading = true;
    return $http.get("../../../../../../../../api/" + $scope.properties.type + "/autocomplete?str=" + $scope.properties.value + "&bundles=" + $scope.properties.bundles).then(function(r){
        var items = r.data
        var output = [];
        if($scope.properties.type == "user"){
            for(var k in items){
                var item = items[k];
                var login = item.login;
                var mail = item.mail;
                var displayname = item.displayname;
                var icon = item.icon
                
                output.push( item.icon + " "
                + item.displayname + " ("
                + item.login + " / "
                + item.mail + ")");
            }
        }else if($scope.properties.type == "node"){
            for(var k in items){
                var item = items[k];
                var nid = item.nid;
                var title = item.title;
                var icon = item.icon;
                
                output.push(item.icon + " "
                + item.title + " ( "
                + item.nid + " )");
            }
        }else if($scope.properties.type == "space"){
            
        }
        $scope.loading = false;
        return output;
    });
  };
  
  this.setData = function($item){
      if($scope.properties.type == "user"){
        $scope.properties.currentTitle=$item.substr($item.indexOf("/> ")+3, $item.lastIndexOf(" ("));  
        $item = $item.substr($item.lastIndexOf(" (")+2);
        $item = $item.substr(0, $item.lastIndexOf(" /"));
      }else if($scope.properties.type == "node"){
        $scope.properties.currentTitle=$item.substr($item.indexOf("/> ")+3, $item.lastIndexOf(" ("));  
        $item = $item.substr($item.lastIndexOf(" ( ")+2);
        $item = $item.substr(0, $item.lastIndexOf(" )"));
      }else if($scope.properties.type == "space"){
      }
      $scope.properties.value = $item;
      $scope.isReadOnly = true;
       console.log("set readonly true");
  }
  
  this.clickInput = function(){
      console.log("click input");console.log($scope.properties.readOnly);console.log($scope.isReadOnly);
      //if(!$scope.properties.readOnly && $scope.isReadOnly){
      if(!$scope.properties.readOnly){
           console.log("click input2");
          $scope.isReadOnly = false;
          $scope.properties.value = "";
          $scope.properties.currentTitle="";
      }
  }
  $scope.isReadOnly = $scope.properties.readOnly;
  this.name = widgetNameFactory.getName('customGofastAutocomplete');
}
,
      template: '<div ng-class="{\n    \'form-horizontal\': properties.labelPosition === \'left\' && !properties.labelHidden,\n    \'row\': properties.labelPosition === \'top\' && !properties.labelHidden || properties.labelHidden\n    }">\n    <div class="form-group">\n        <label\n            ng-if="!properties.labelHidden"\n            ng-class="{ \'control-label--required\': properties.required }"\n            class="control-label col-xs-{{ !properties.labelHidden && properties.labelPosition === \'left\' ? properties.labelWidth : 12 }}">\n            {{ properties.label | uiTranslate }}\n        </label>\n        <div class="col-xs-{{ 12 - (!properties.labelHidden && properties.labelPosition === \'left\' ? properties.labelWidth : 0) }}" >\n            <input\n                type="text"\n                class="form-control"\n                placeholder="{{properties.placeholder}}"\n                typeahead-append-to-body="true"\n                typeahead="i for i in ctrl.getData()"\n                typeahead-template-url="customTypeaheadForInputAutocomplete.html"\n                typeahead-wait-ms="500"\n                typeahead-on-select="ctrl.setData($item)"\n                typeahead-min-length="3"\n                ng-model="properties.value"\n                ng-model-options="{ allowInvalid: true }"\n                name="{{ctrl.name}}"\n                ng-readonly="isReadOnly"\n                ng-click="ctrl.clickInput()">\n                \n                <div ng-if="loading" class="loader-autocomplete"></div>\n                <span ng-click="ctrl.clickInput()" style="position: absolute;left: 25px;color:#555;background-color: #eee;top: 7px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;width: 74%;" ng-bind="properties.currentTitle"></span>\n                \n            <!-- It doesn\'t work if we put it inside form.html -->\n            <script type="text/ng-template" id="customTypeaheadForInputAutocomplete.html">\n                <a  bind-html-unsafe="match.label | typeaheadHighlight:query"></a>\n            </script>\n        </div>\n    </div>\n</div>\n\n<style>\n    .loader-autocomplete{\n        border:3px solid #f3f3f3;\n        border-radius: 50%;\n        border-top: 3px solid #3498db;\n        border-bottom: 3px solid #3498db;\n        width:20px;\n        height:20px;\n        -webkit-animation: spin 2s linear infinite;\n        animation: spin-loader 2s linear infinite;\n        margin: 0 auto;\n        position: absolute;\n        top:8px;\n        right:20px;\n    }\n    \n    @keyframes spin-loader{\n        0% {transform: rotate(0deg);}\n        100% {transform: rotate(360deg);}\n    }\n</style>'
    };
  });
