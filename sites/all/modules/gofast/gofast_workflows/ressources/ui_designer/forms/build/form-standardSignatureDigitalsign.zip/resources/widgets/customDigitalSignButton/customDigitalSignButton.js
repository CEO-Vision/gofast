(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customDigitalSignButton', function() {
    return {
      controllerAs: 'ctrl',
      controller: function PbButtonCtrl($scope) {
  "use strict";

  this.action = function action() {
    document
      .querySelector("[data-id='digitalsign_signing_iframe']")
      .setAttribute("src", $scope.properties.requestUrl + "?type=update&signreqid=" + $scope.properties.requestId);
    document.querySelector("[data-id='digitalsign_signing_iframe']").style.display =
      "block";
    document.querySelector(".btn-danger").style.display = "none";
  };
}
,
      template: '<div class="text-{{ properties.alignment }}">\n    <button\n        ng-class="\'btn btn-\' + properties.buttonStyle"\n        ng-click="ctrl.action()"\n        type="button"\n        ng-disabled="properties.disabled || ctrl.busy" ng-bind-html="properties.label | gfTranslate"></button>\n</div>\n'
    };
  });
