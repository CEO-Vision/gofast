(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customGofastYousignIframe', function() {
    return {
      controllerAs: 'ctrl',
      controller: function CustomGofastPdfViewer($scope, $sce, $http) {
    this.getLink = function(){
        $(".loader-pdf").show();
             $(".loader-pdf").hide();
             $scope.urlRetrieved = $sce.trustAsResourceUrl("../../../../../../../../signature/yousign/bonita/widget?procedure_id=" + $scope.properties.procedure);
             return true;
    }
    
    $scope.$watch("properties.procedure", function(){
        $scope.ctrl.getLink();
    })
},
      template: '<div class="thumbnail2">\n    <div class="loader-pdf"></div>\n    <iframe ng-init="ctrl.getLink()" ng-src="{{urlRetrieved}}"  style="min-height:{{properties.height}}px;height: {{properties.height}}px; width:100%;" frameborder="0" scrolling="auto"></iframe>\n</div>\n\n<style>\n    .loader-pdf{\n        border: 3px solid #f3f3f3;\n        border-radius: 50%;\n        border-top: 3px solid #3498db;\n        border-bottom: 3px solid #3498db;\n        width: 20px;\n        height: 20px;\n        -webkit-animation: spin 2s linear infinite;\n        animation: spin-loader 2s linear infinite;\n        margin: 0 auto;\n        float: left;\n        position: absolute;\n    }\n    @keyframes spin-loader{\n        0% { transform: rotate(0deg); }\n        100% { transform: rotate(360deg); }\n    }\n</style>'
    };
  });
