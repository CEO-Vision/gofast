(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customCustomizableIframe', function() {
    return {
      template: '<iframe data-id="{{ properties.iframeId }}" src="{{ properties.src }}" style="{{ properties.style }}"></iframe>'
    };
  });
