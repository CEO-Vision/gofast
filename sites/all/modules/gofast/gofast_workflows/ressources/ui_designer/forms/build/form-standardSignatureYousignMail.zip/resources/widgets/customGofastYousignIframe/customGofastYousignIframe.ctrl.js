function CustomGofastPdfViewer($scope, $sce, $http) {
    this.getLink = function(){
        $(".loader-pdf").show();
             $(".loader-pdf").hide();
             $scope.urlRetrieved = $sce.trustAsResourceUrl("../../../../../../../../signature/yousign/bonita/widget?procedure_id=" + $scope.properties.procedure);
             return true;
    }
    
    $scope.$watch("properties.procedure", function(){
        $scope.ctrl.getLink();
    })
}