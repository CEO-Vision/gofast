(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customGofastAutocompleteContact', function() {
    return {
      controllerAs: 'ctrl',
      controller: function CustomGofastAutocompleteCtrl($scope, $parse, $log, widgetNameFactory, $http) {
  $scope.loading = false;
  
  this.getData = function ($field) {
    $scope.loading = true;
    if($field == "firstname"){
        $str = $scope.properties.valueFirstname;
    }else{
        $str = $scope.properties.value;
    }
    return $http.get("../../../../../../../../api/contact/autocomplete?str=" + $str).then(function(r){
        var items = r.data
        var output = [];
            for(var k in items){
                var item = items[k];
                var lastname = item.name;
                var firstname = item.firstname;
                var phone = item.mobile;
                var mail = item.email;
                var entity = item.entity;
                var address = item.address;
                output.push( item.name + " , " + item.firstname + " , " +item.email + " , " + item.mobile + " , " + item.entity);
            }
        $scope.loading = false;
        return output;
    });
  };
  
  this.setData = function($item){
       var array_item = $item.split(' , ');
      $scope.properties.currentTitle=array_item[0];
      $scope.properties.currentTitleFirstname=array_item[1];  
      $scope.properties.currentTitleEmail=array_item[2];
      $scope.properties.currentTitleMobile=array_item[3]; 
      $scope.properties.currentTitleEntity=array_item[4];

      $scope.properties.value = array_item[0];
      $scope.properties.valueFirstname = array_item[1];
      $scope.properties.valueEmail = array_item[2];
      $scope.properties.valueMobile = array_item[3];
      $scope.properties.valueEntity = array_item[4];
  }
  
  this.clickInput = function($element){
      if($element == 'email'){
        $scope.properties.currentTitleEmail = "";
        $scope.properties.currentTitleEmail = "";
      }else if($element == 'firstname'){
        $scope.properties.valueFirstname = "";
        $scope.properties.currentTitleFirstname = "";
      }else if($element == 'lastname'){
        $scope.properties.value = "";
        $scope.properties.currentTitle = "";
      }else if($element == 'mobile'){
        $scope.properties.valueMobile = "";
        $scope.properties.currentTitleMobile="";
      }else if($element == 'entity'){
        $scope.properties.valueEntity = "";
        $scope.properties.currentTitleEntity="";
      }
     
  }
  
  this.name = widgetNameFactory.getName('customGofastAutocomplete');
}
,
      template: '<div class="col-xs-3" style="padding:0px;">\n    <div class="form-group">\n        <label\n            ng-if="!properties.labelHidden"\n            ng-class="{ \'control-label--required\': properties.required }"\n            class="control-label col-xs-{{ !properties.labelHidden && properties.labelPosition === \'left\' ? properties.labelWidth : 12 }}" style="padding:0px;">\n            {{ properties.label | uiTranslate }}\n        </label>\n        <div class="col-xs-{{ 12 - (!properties.labelHidden && properties.labelPosition === \'left\' ? properties.labelWidth : 0) }}" style="padding:0px;" >\n            <input\n                type="text"\n                class="form-control"\n                placeholder="{{properties.label}}"\n                typeahead-append-to-body="true"\n                typeahead="i for i in ctrl.getData(\'lastname\')"\n                typeahead-template-url="customTypeaheadForInputAutocomplete.html"\n                typeahead-wait-ms="500"\n                typeahead-on-select="ctrl.setData($item)"\n                typeahead-min-length="3"\n                ng-model="properties.value"\n                ng-model-options="{ allowInvalid: true }"\n                name="{{ctrl.name}}"\n                ng-readonly="false"\n                ng-click="ctrl.clickInput()">\n                \n                <div ng-if="loading" class="loader-autocomplete"></div>\n                <span ng-click="ctrl.clickInput(\'lastname\')" style="position: absolute;left: 3px;color:#555;background-color: #eee;top: 7px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;width: 95%;" ng-bind="properties.currentTitle"></span>\n                \n            <!-- It doesn\'t work if we put it inside form.html -->\n            <script type="text/ng-template" id="customTypeaheadForInputAutocomplete.html">\n                <a  bind-html-unsafe="match.label | typeaheadHighlight:query"></a>\n            </script>\n        </div>\n    </div>\n</div>\n<div class="col-xs-3" style="padding:0px;padding-left:6px;">\n    <div class="form-group">\n         <label\n            ng-if="!properties.labelHidden"\n            ng-class="{ \'control-label--required\': properties.required }"\n            class="control-label col-xs-{{ !properties.labelHidden && properties.labelPosition === \'left\' ? properties.labelWidth : 12 }}" style="padding:0px;">\n            {{ properties.labelFirstname | uiTranslate }}\n        </label>\n           <div class="col-xs-{{ 12 - (!properties.labelHidden && properties.labelPosition === \'left\' ? properties.labelWidth : 0) }}" style="padding:0px;" >\n            <input\n                type="text"\n                class="form-control"\n                placeholder="{{properties.labelFirstname}}"\n                typeahead="i for i in ctrl.getData(\'firstname\')"\n                typeahead-template-url="customTypeaheadForInputAutocomplete.html"\n                typeahead-wait-ms="500"\n                typeahead-on-select="ctrl.setData($item)"\n                typeahead-min-length="3"\n                ng-model="properties.valueFirstname"\n                ng-model-options="{ allowInvalid: true }"\n                name="{{ctrl.name}}"\n                ng-readonly="false">\n                \n                <div ng-if="loading" class=""></div>\n                <span ng-click="ctrl.clickInput(\'firstname\')" style="position: absolute;left: 3px;color:#555;background-color: #eee;top: 7px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;width: 95%;" ng-bind="properties.currentTitleFirstname"></span>\n          <!-- It doesn\'t work if we put it inside form.html -->\n            <script type="text/ng-template" id="customTypeaheadForInputAutocomplete.html">\n                <a  bind-html-unsafe="match.label | typeaheadHighlight:query"></a>\n            </script>\n        </div>\n    </div>\n</div>\n<div class="col-xs-3" style="padding:0px;padding-left:6px;">\n    <div class="form-group">\n          <label\n            ng-if="!properties.labelHidden"\n            ng-class="{ \'control-label--required\': properties.required }"\n            class="control-label col-xs-{{ !properties.labelHidden && properties.labelPosition === \'left\' ? properties.labelWidth : 12 }}" style="padding:0px;">\n            {{ properties.labelEmail | uiTranslate }}\n        </label>\n           <div class="col-xs-{{ 12 - (!properties.labelHidden && properties.labelPosition === \'left\' ? properties.labelWidth : 0) }}" style="padding:0px;">\n            <input\n                type="text"\n                class="form-control"\n                placeholder="{{properties.labelEmail}}"\n                ng-model="properties.valueEmail"\n                ng-model-options="{ allowInvalid: true }"\n                name="{{ctrl.name}}"\n                ng-readonly="false">\n                \n                <div ng-if="loading" class=""></div>\n                <span ng-click="ctrl.clickInput(\'email\')" style="position: absolute;left: 3px;color:#555;background-color: #eee;top: 7px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;width: 95%;" ng-bind="properties.currentTitleEmail"></span>\n         \n        </div>\n    </div>\n</div>\n<div class="col-xs-3" style="padding:0px;padding-left:6px;">\n    <div class="form-group">\n         <label\n            ng-if="!properties.labelHidden"\n            ng-class="{ \'control-label--required\': properties.required }"\n            class="control-label col-xs-{{ !properties.labelHidden && properties.labelPosition === \'left\' ? properties.labelWidth : 12 }}" style="padding:0px;">\n            {{ properties.labelMobile | uiTranslate }}\n        </label>\n        <div class="col-xs-{{ 12 - (!properties.labelHidden && properties.labelPosition === \'left\' ? properties.labelWidth : 0) }}" style="padding:0px;" >\n            <input\n                type="text"\n                class="form-control"\n                placeholder="{{properties.labelMobile}}"\n                ng-model="properties.valueMobile"\n                ng-model-options="{ allowInvalid: true }"\n                name="{{ctrl.name}}"\n                ng-readonly="false">\n                \n                <div ng-if="loading" class=""></div>\n                <span ng-click="ctrl.clickInput(\'mobile\')" style="position: absolute;left: 3px;color:#555;background-color: #eee;top: 7px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;width: 95%;" ng-bind="properties.currentTitleMobile"></span>\n         \n        </div>\n    </div> \n</div>\n<div ng-class="{\n    \'form-horizontal\': properties.labelPosition === \'left\' && !properties.labelHidden,\n    \'row\': properties.labelPosition === \'top\' && !properties.labelHidden || properties.labelHidden\n    }">\n    <div class="form-group">\n         <label\n            ng-if="!properties.labelHidden"\n            ng-class="{ \'control-label--required\': properties.required }"\n            class="control-label col-xs-{{ !properties.labelHidden && properties.labelPosition === \'left\' ? properties.labelWidth : 12 }}">\n            {{ properties.labelEntity | uiTranslate }}\n        </label> \n        <div ng-if="!properties.hideEntity" class="col-xs-{{ 12 - (!properties.labelHidden && properties.labelPosition === \'left\' ? properties.labelWidth : 0) }}" >\n            <input\n                type="text"\n                class="form-control"\n                placeholder="{{properties.placeholder}}"\n                ng-model="properties.valueEntity"\n                ng-model-options="{ allowInvalid: true }"\n                name="{{ctrl.name}}"\n                ng-readonly="false">\n                \n                <div ng-if="loading" class=""></div>\n                <span ng-click="ctrl.clickInput(\'entity\')" style="position: absolute;left: 3px;color:#555;background-color: #eee;top: 7px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;width: 95%;" ng-bind="properties.currentTitleEntity"></span>\n         \n        </div>\n        \n    </div>\n</div>\n\n<style>\n    .loader-autocomplete{\n        border:3px solid #f3f3f3;\n        border-radius: 50%;\n        border-top: 3px solid #3498db;\n        border-bottom: 3px solid #3498db;\n        width:20px;\n        height:20px;\n        -webkit-animation: spin 2s linear infinite;\n        animation: spin-loader 2s linear infinite;\n        margin: 0 auto;\n        position: absolute;\n        top:8px;\n        right:20px;\n    }\n    \n    @keyframes spin-loader{\n        0% {transform: rotate(0deg);}\n        100% {transform: rotate(360deg);}\n    }\n</style>'
    };
  });
