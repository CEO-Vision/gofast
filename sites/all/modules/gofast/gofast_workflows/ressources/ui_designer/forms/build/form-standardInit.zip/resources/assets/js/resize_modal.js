window.parent.parent.window.jQuery("#modal-content").css("max-width", "none");
window.parent.parent.window.jQuery("#modal-content").css("width", (window.parent.parent.window.innerWidth-100) + "px");

window.parent.parent.window.jQuery("#modal-content").css("max-height", "none");
window.parent.parent.window.jQuery("#modal-content").css("height", (window.parent.parent.window.innerHeight-150) + "px");

window.parent.parent.window.jQuery("#modal-content #bonita_form_process").css("height", (window.parent.parent.window.innerHeight-150) + "px");


window.parent.parent.window.jQuery("#modal-content #bonita_form_process").css("height", (window.parent.parent.window.innerHeight-150) + "px");

setTimeout(function(){
           window.parent.parent.window.jQuery("#modal-content #bonita_form_process").css("height", (window.parent.parent.window.innerHeight-150) + "px");
			window.parent.parent.window.jQuery("#modal-content #bonita_form_process").css("min-height", (window.parent.parent.window.innerHeight-150) + "px");
}, 1500);


window.parent.parent.window.modalContentResize();

window.parent.parent.window.jQuery(".modal-content > .ui-resizable").css("width", (window.parent.parent.window.innerWidth-100) + "px");
window.parent.parent.window.jQuery("#modal-content").css("width", "auto");
window.parent.parent.window.jQuery("#modal-content").css("max-width", "none");
window.parent.parent.window.jQuery(".modal-content > .ui-resizable").css("height", (window.parent.parent.window.innerHeight-150) + "px");
window.parent.parent.window.jQuery("#modal-content").css("height", "auto");