if(window.parent.parent.window.innerWidth < 1025){
    window.parent.parent.window.jQuery("#modal-content").css("max-width", "none");
    window.parent.parent.window.jQuery("#modal-content").css("width", (window.parent.parent.window.innerWidth-10) + "px");
    
    window.parent.parent.window.jQuery("#modal-content").css("max-height", "none");
    window.parent.parent.window.jQuery("#modal-content").css("height", (window.parent.parent.window.innerHeight-50) + "px");
    
    jQuery("iframe").css("height", (window.parent.parent.window.innerHeight-50) + "px");
    
    setTimeout(function(){
                jQuery("iframe").css("height", (window.parent.parent.window.innerHeight-150) + "px");
    }, 1000);
    
    if(typeof window.parent.parent.window.modalContentResize != "undefined"){
        window.parent.parent.window.modalContentResize();
    }
    window.parent.document.querySelector("#bonita_form").style.minHeight = ""
}else{   

    window.parent.parent.window.jQuery("#modal-content").css("max-width", "none");
    window.parent.parent.window.jQuery("#modal-content").css("width", (window.parent.parent.window.innerWidth-150) + "px");
    
    window.parent.parent.window.jQuery("#modal-content").css("max-height", "none");
    window.parent.parent.window.jQuery("#modal-content").css("height", (window.parent.parent.window.innerHeight-150) + "px");
    
    jQuery("iframe").css("height", (window.parent.parent.window.innerHeight-150) + "px");
    
    setTimeout(function(){
                jQuery("iframe").css("height", (window.parent.parent.window.innerHeight-250) + "px");
    }, 1000);
    
    
    if(typeof window.parent.parent.window.modalContentResize != "undefined"){
        window.parent.parent.window.modalContentResize();
    }
    window.parent.document.querySelector("#bonita_form").style.minHeight = ""
}

