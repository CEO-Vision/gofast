function CustomGofastPdfViewer($scope, $sce, $http) {
    this.getLink = function(){
        $(".loader-pdf").show();
        let link = "../../../../../../../../api/node/preview_link?nid=" + $scope.properties.nodeId;
        if ($scope.properties.caseId > 0) {
            link += "&caseId=" + $scope.properties.caseId;
        }
        return $http.get(link).then(function(r){
             $(".loader-pdf").hide();
             $scope.urlRetrieved = $sce.trustAsResourceUrl(r.data.link);
             return true;
        });
    }
    
    $scope.$watch("properties.caseId", function(){
        $scope.ctrl.getLink();
    })
    $scope.$watch("properties.nodeId", function(){
        $scope.ctrl.getLink();
    })
}