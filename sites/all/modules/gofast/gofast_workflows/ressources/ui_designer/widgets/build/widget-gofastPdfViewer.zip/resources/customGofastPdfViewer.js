(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customGofastPdfViewer', function() {
    return {
      controllerAs: 'ctrl',
      controller: function CustomGofastPdfViewer($scope, $sce, $http) {
    this.getLink = function(){
        if(Number.isNaN(parseInt($scope.properties.nid))){
            $(".loader-pdf").hide();
            return false;
        }
        $(".loader-pdf").show();
        let link = "../../../../../../../../api/node/preview_link?nid=" + $scope.properties.nid;
        if ($scope.properties.caseId > 0) {
            link += "&caseId=" + $scope.properties.caseId;
        }
        return $http.get(link).then(function(r){
             $(".loader-pdf").hide();
             $scope.urlRetrieved = $sce.trustAsResourceUrl(r.data.link);
             return true;
        });
    }
    
    $scope.$watch("properties.nid", function(){
        $scope.ctrl.getLink();
    })
},
      template: '<div class="thumbnail">\n    <div class="loader-pdf"></div>\n    <iframe ng-init="ctrl.getLink()" ng-src="{{urlRetrieved}}" style="height: {{properties.height}}px !important; width:100%;" frameborder="0" scrolling="no"></iframe>\n</div>\n\n<style>\n    .loader-pdf{\n        border: 3px solid #f3f3f3;\n        border-radius: 50%;\n        border-top: 3px solid #3498db;\n        border-bottom: 3px solid #3498db;\n        width: 20px;\n        height: 20px;\n        -webkit-animation: spin 2s linear infinite;\n        animation: spin-loader 2s linear infinite;\n        margin: 0 auto;\n        float: left;\n        position: absolute;\n    }\n    @keyframes spin-loader{\n        0% { transform: rotate(0deg); }\n        100% { transform: rotate(360deg); }\n    }\n</style>'
    };
  });
