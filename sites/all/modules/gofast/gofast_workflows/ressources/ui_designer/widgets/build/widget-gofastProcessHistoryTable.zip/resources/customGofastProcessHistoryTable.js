(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customGofastProcessHistoryTable', function() {
    return {
      controllerAs: 'ctrl',
      controller: function PbTableCtrl($scope, $http, $sce, $filter) {
     $scope.final_content = [];

     $scope.$watch("properties.instancesIds", function(){
          if(typeof $scope.properties.instancesIds == "undefined"){
              return;
          }
         
           for (var property in $scope.properties.instancesIds) {
                if ($scope.properties.instancesIds.hasOwnProperty(property)) {
                       //load process object manually
                    $http.get("/bonita/API/bdm/businessData/com.company.model.ProcessHistory/"+$scope.properties.instancesIds[property].persistenceId).then( 
                        function successCallback(response) {
                            var processObject = new Object();
                            processObject.title = response.data.title;
                            processObject.start_date = response.data.start_date;
                            processObject.deadline = get_deadline_html(response, processObject);
                            processObject.actor = get_initiator_html(response, processObject);
                            processObject.persistenceId = response.data.persistenceId;
                            processObject.finished_date = get_finished_date(response);
                            $scope.final_content.push(processObject);
                        }
                    );
           }   
         }
    
     } );        

  this.isArray = Array.isArray;

 function get_finished_date(ProcessHistory){

       var last_line = ProcessHistory.data.lines[ProcessHistory.data.lines.length-1];
       var finished_date = last_line.line_date;
       return finished_date;
 }

  function get_initiator_html(myProcessHistory, myTask){
      var initiator_string = myProcessHistory.data.initiator;
      var url = "/api/user/picture?username="+initiator_string;
       $http.get(url).then( 
                   function successCallback(response) {
                        var label_actor = $filter('gfTranslateHistory')("label.started_by");
                        myTask.actor = $sce.trustAsHtml("<div style='clear:both;'>"+label_actor+"  : "+response.data.content+"</div>");
                   }    
            );  
  }
  
    $scope.ceo_vision_js_process_pageflow = function(){
      var row = $scope.properties.selectedRow;
      console.log(row);
      window.parent.parent.Drupal.gofast_workflows.ceo_vision_js_process_pageflow("bdm", "", row.persistenceId,"");
      
  };

  this.isClickable = function () {
    return $scope.properties.isBound('selectedRow');
  };

  this.selectRow = function (row) {
    if (this.isClickable()) {
      $scope.properties.selectedRow = row;
    }
  };
  
    function get_deadline_html(processVariables, myTask){
      var d = new Date(processVariables.end_date);
      var timestamp_now = new Date().getTime() / 1000;
      var timestamp = d.getTime() / 1000;
      
      if(timestamp_now > timestamp){
           var label_deadline = $filter('gfTranslateHistory')("label.process_outdated");
           myTask.deadline_description = label_deadline;
           myTask.deadline_color = "#c0392b";
       }else if(timestamp - timestamp_now < 60*60*24){
           var label_deadline = $filter('gfTranslateHistory')("label.process_soon_outdated");
           myTask.deadline_description = label_deadline;
           myTask.deadline_color = "#d35400";
       }else{
           myTask.deadline_description = "";
           myTask.deadline_color = "#2ecc71";
       }
      
    myTask.has_deadline = true;
    if(processVariables.end_date === null || typeof processVariables.end_date == "undefined"){
        processVariables.end_date = " / ";
        myTask.has_deadline = false;
    }
      var deadline_html = processVariables.end_date;
    
      return deadline_html;
  }

  this.isSelected = function(row) {
    return angular.equals(row, $scope.properties.selectedRow);
  };
  
}
,
      template: '<div class="table-responsive">\n    <table class="table" ng-class="{\'table-hover\': ctrl.isClickable()}">\n        <thead>\n             <tr>\n                <th>\n                </th>\n            </tr>\n        </thead>\n         <tbody ng-if="ctrl.isArray(final_content)">\n            <tr style="cursor:auto;background-color:white;" ng-repeat="row in final_content" ng-click="ctrl.selectRow(row)" ng-class="">\n                <td>\n                    \n                  <div class="task_in_todoliste" style="list-style: none;padding: 1px 2px;position: relative;" >\n                    \n                    <div style="float:right;">\n                       <span ng-bind-html="row.actor" class="ng-binding ng-scope card-text actor_container" style="display: inline-block;"></span> \n                    </div>\n                    <div style="padding-left:0;">\n                        <div class="row">\n                            <span style="color:#337ab7;width:40%;white-space: nowrap;overflow:hidden;text-overflow:ellipsis;-o-text-overflow:ellipsis;display: inline-block;" title=\'{{"label.process_title" | gfTranslateHistory}}\'>\n                                <i class="fa fa-cogs"></i>\n                                <span class="card-title">{{row.title}}</span>\n                            </span>\n                            <span style="color:#337ab7;font-weight: bold;white-space: nowrap;overflow:hidden;text-overflow:ellipsis;-o-text-overflow:ellipsis;display: inline-block;">\n                                <i class="fa fa-check"></i>\n                                <span class="card-subtitle mb-2 text-muted"></span>\n                            </span>\n                        </div>\n                        <div class="row">\n                            <div>\n                                <div class="deadline_box_in_rapide_todoliste" style="float:left;width:40%;max-height:22px;overflow:hidden;text-overflow:ellipsis;-o-text-overflow:ellipsis;display: inline-block;">\n                                   <i class="glyphicon glyphicon-time"></i> <span title=\'{{"label.process_start_date" | gfTranslateHistory}}\'>{{row.start_date|date:"dd/MM/yyyy"}}</span>\n                                </div>\n                               <!--<div class="deadline_box_in_rapide_todoliste" style="font-weight:bold;cursor:pointer;float:left;width:5%;text-align:center;px;max-height:22px;overflow:hidden;text-overflow:ellipsis;-o-text-overflow:ellipsis;display: inline-block;">\n                                   <i ng-if="row.has_deadline" class="fa fa-stop" style="color:#337ab7;"></i> <span style="color:{{row.deadline_color}};" title=\'{{"label.process_deadline" | gfTranslateHistory}}\'>{{row.deadline|date:"dd/MM/yyyy"}}</span>\n                                </div>-->\n                                <div class="deadline_box_in_rapide_todoliste" style="float:left;width:40%;max-height:22px;overflow:hidden;text-overflow:ellipsis;-o-text-overflow:ellipsis;display: inline-block;">\n                                   <i class="glyphicon glyphicon-time"></i> <span title=\'{{"label.process_end_date" | gfTranslateHistory}}\'>{{row.finished_date|date:"dd/MM/yyyy"}}</span>\n                                </div>\n                                \n                                <div class="deadline_box_in_rapide_todoliste" style="float:left;max-width:185px;max-height:22px;">\n                                     <div ng-bind-html="row.documents" class="ng-binding ng-scope card-text document_container"></div>\n                                </div>\n                                \n                                <div id="wf-buttons" style="float: right;margin-right: 0;">\n                                    <span ng-if="row.is_author" class="gofast_workflows_title_task_doit" style="cursor:pointer;" ng-click=\'ctrl.selectRow(row);ceo_vision_js_task_doit();\' title=\'{{"label.process_doit" | gfTranslateHistory}}\'>\n                                        <button type="button" class="btn btn-default wf-button wf-button-green" style="padding: 1px 6px;color: #2ecc71;">\n                                            <span class="fa fa-check gofast_wf_link"></span>\n                                        </button>\n                                    </span>\n                                    <span style="cursor:pointer;" ng-click=\'ctrl.selectRow(row);ceo_vision_js_process_pageflow();\' title=\'{{"label.process_history" | gfTranslateHistory}}\'>\n                                        <button type="button" class="btn btn-default wf-button wf-button-blue" style="padding: 1px 6px;color: #337ab7;">\n                                            <span class="fa fa-info gofast_wf_link"></span>\n                                        </button> \n                                    </span>\n                        </div>\n                            </div>\n                        </div>\n                    </div>\n                    <div style="clear:both;"></div>\n                </div>\n                </td>\n            </tr>\n        </tbody>\n       \n    </table>\n</div>\n'
    };
  });
