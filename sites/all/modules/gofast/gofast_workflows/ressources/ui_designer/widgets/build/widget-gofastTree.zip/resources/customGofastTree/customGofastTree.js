(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customGofastTree', function() {
    return {
      controllerAs: 'ctrl',
      controller: function CustomGofastTree($scope, $parse, widgetNameFactory, $log, $http) {
    this.addWebfontIcon = function(treeId, treeNode){
        var aObj = $("#" + treeNode.tId + "_ico");
        //retreive taxo icone
        style = aObj.css('background-image');
        var cleanup = /\"|\'|\)/g;
        icon = style.split('/').pop().replace('%20', ' ').replace(cleanup, '');

        if ($("#webfont_icon_"+treeNode.tId).length>0) return;
        var editStr = " <span id='webfont_icon_" +treeNode.tId+ "' class='fa "+icon+"'> </span>";
        aObj.prepend(editStr);
        aObj.css('background', 'transparent');
    }
    
    this.selectClicked = function(e, tid, tnode){
        $scope.zTree.checkNode(tnode, !tnode.checked, false, false);
		$scope.properties.selectedData = JSON.stringify($scope.zTree.getCheckedNodes().map(node => node.ename));
        $scope.$apply();
    }
	
	this.selectCheck = function(tid, tnode){
		$scope.zTree.checkNode(tnode, !tnode.checked, false, false);
		$scope.properties.selectedData = JSON.stringify($scope.zTree.getCheckedNodes().map(node => node.ename));
        $scope.$apply();
		return false;
    }
    
    this.decodeTreeData = function(tid, pnode, r){
        return JSON.parse(r.tree);
    }
	
	this.otherParam = function(tid, pnode, r){
        if(pnode == null && $scope.properties.origin !== null){
			return {ename: $scope.properties.origin};
		}
		return [];
    }
    
    this.beforeAsync = function(){
        $(".loader-tree").show();
    }
    
    this.onAsyncSuccess = function(){
        $(".loader-tree").hide();
    }
    
    this.onAsyncSuccess = function(){
        $(".loader-tree").hide();
    }
        
    var callbacks = {
        onClick: $scope.ctrl.selectClicked,
		beforeCheck: $scope.ctrl.selectCheck,
        beforeAsync: $scope.ctrl.beforeAsync,
        onAsyncSuccess: $scope.ctrl.onAsyncSuccess,
        onAsyncError: $scope.ctrl.onAsyncError,
    }
    
    $scope.setting = {
      check: {
          enable: true,
          chkStyle: $scope.properties.chkStyle
      },
      view: {
        showLine: true,
        selectedMulti: true,
        addDiyDom: $scope.ctrl.addWebfontIcon
      },
      data: {
        keep: {
            parent: true
        }
      },
      async: {
          enable: true,
          url: "../../../../../../../../api/locations/tree",
          autoParam: ["ename"],
		  otherParam: $scope.ctrl.otherParam,
          contentType: "application/json",
          dataFilter: $scope.ctrl.decodeTreeData,
          type: 'POST'
      },
      callback: callbacks
    };
        
    $scope.t = jQuery("#tree");
    $scope.t = jQuery.fn.zTree.init($scope.t, $scope.setting);
    $scope.zTree = jQuery.fn.zTree.getZTreeObj("tree");
}
,
      template: '<div class="thumbnail">\n <div class="loader-tree"></div>\n <ul id="tree" class="ztree" style="height: {{properties.height}}px !important;"></ul>\n</div>\n\n<style>\n    #tree{\n        width: 100% !important;\n        overflow:auto;\n    }\n    .fa{\n        color: steelblue;\n    }\n    .loader-tree{\n        border: 3px solid #f3f3f3;\n        border-radius: 50%;\n        border-top: 3px solid #3498db;\n        border-bottom: 3px solid #3498db;\n        width: 20px;\n        height: 20px;\n        -webkit-animation: spin 2s linear infinite;\n        animation: spin-loader 2s linear infinite;\n        margin: 0 auto;\n        float: left;\n        position: absolute;\n    }\n    @keyframes spin-loader{\n        0% { transform: rotate(0deg); }\n        100% { transform: rotate(360deg); }\n    }\n    \n    #tree_1_switch, #tree_1_check, #tree_1_a{\n        display:none;\n    }\n</style>'
    };
  });
