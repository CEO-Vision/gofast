(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customGofastTasksTable', function() {
    return {
      controllerAs: 'ctrl',
      controller: function PbTableCtrl($scope, $http, $sce, $filter) {
     $scope.pagination = [];

     $scope.task_ids = "";
     $scope.$watch("properties.content", function(){
          if(typeof $scope.properties.content == "undefined"){
              return;
          }
         $scope.final_content = [];
         $scope.build_pagination();
         $scope.properties.content.forEach(function(myTaskContent) {
             $scope.task_ids = typeof myTaskContent.id !== "undefined" ? $scope.task_ids+myTaskContent.id+"-" : $scope.task_ids+"kanban-";
         });

         $http.get("/bonita/API/extension/getTasksAllInfos?taskids="+$scope.task_ids).then(
           function successCallback(response) {
                var i = 0;
                response.data.response.content.forEach(function(myTask) {

                    if(typeof myTask.type !== "undefined" && myTask.type == "kanban"){

                        var kanban_element = $scope.properties.content[i];

                        if(kanban_element.closest_deadline_color_indicator == "deadline-nearly-reached"){
                            myTask.deadline_color = "#d35400";
                        }else if(kanban_element.closest_deadline_color_indicator == "deadline-reached"){
                            myTask.deadline_color = "#c0392b";
                        }else if(kanban_element.closest_deadline_color_indicator == 'deadline-reached-off' || kanban_element.closest_deadline_color_indicator == 'deadline-nearly-reached-off' ){
                            myTask.deadline_color = "#b5b5c3";
                        }else{
                            myTask.deadline_color = "#2ecc71";
                        }

                        if(typeof kanban_element.closest_deadline !== "undefined" && kanban_element.closest_deadline !== ""){
                            myTask.deadline = kanban_element.closest_deadline;
                            myTask.has_deadline = true;
                        }
                        if(typeof kanban_element.deadline !== "undefined" && kanban_element.deadline !== ""){
                            myTask.has_process_end_date = true;
                            myTask.process_end_date = kanban_element.deadline;
                        }

                        myTask.deadline_timestamp = kanban_element.closest_deadline_timestamp;
                        myTask.actor = get_kanban_user_html(myTask, kanban_element.person_in_charge);
                        myTask.alt_title = $filter('gfTranslate')("label.completed_at") + " " + kanban_element.progress + "%";
                        myTask.title = kanban_element.title;
                        myTask.displayDescription = kanban_element.first_item_label+" ("+myTask.alt_title+")";
                        myTask.type_icon = "fab fa-trello";
                        myTask.nid = kanban_element.nid;
                        myTask.documents = get_kanban_documents_html(kanban_element.attachments, myTask);
                    }else{

                        myTask.title = myTask.processHistory.title;
                        myTask.alt_title = myTask.title;
                        if($scope.properties.session.user_id == myTask.assigned_id){
                            myTask.is_author = true;
                        }else{
                            myTask.is_author = false;
                        }

                        myTask.deadline_timestamp = new Date(myTask.processCurrent.end_date).getTime()/1000;
                        myTask.actor = get_initiator_html(myTask.processHistory, myTask);
                        myTask.documents = get_documents_html(myTask.processCurrent, myTask);
                        myTask.deadline = get_deadline_html(myTask.processCurrent,myTask);
                        myTask.process_end_date = myTask.processCurrent.end_date;
                        myTask.has_process_end_date = true;
                        myTask.processName = myTask.processInstance.name;
                        myTask.processVersion = myTask.processInstance.version;
                        myTask.processId = myTask.processInstance.id;
                        myTask.type_icon = "fas fa-cogs";
                        myTask.can_delete = get_variable_can_delete_instance(myTask.processCurrent, myTask.processInstance);
                        myTask.can_delegate_task = myTask.processDefinitition.name.toLowerCase() == "document broadcast" && myTask.assigned_id !== 0 && myTask.is_eligible;
                        myTask.is_assigned_group_task = myTask.assigned_id !== 0 && myTask.login.startsWith("ul_");
                    }

                    $scope.final_content.push(myTask);
                    i++;
           });

		   //Sort deadline for both process and kanban tasks
		   $scope.final_content.sort(function(a, b){
			   return a.deadline_timestamp - b.deadline_timestamp;
		   });

        });

     });


  this.isArray = Array.isArray;

    $scope.build_pagination = function(){
          $scope.$watch("properties.pageCount", function(){
          if(typeof $scope.properties.pageCount == "undefined"){
              return;
          }
          $scope.pagination = [];
          var results_count = typeof $scope.properties.pageCount == "object" ? $scope.properties.pageCount.getResponseHeader('Content-Range').replace("0-0/", "") : $scope.properties.pageCount;
          var number_page = results_count / 5;

          var i;
          for (i = 0; i < number_page; i++) {
                page_label = i + 1;
                if(i == $scope.properties.page){
                    var btn_class = "btn_active";
                }else{
                    var btn_class = "";
                }
                var my_page_object = {number:i, label:page_label, btn_class:btn_class}
                $scope.pagination.push(my_page_object);
           }
        });

  }


   $scope.change_page = function($event){
       if($scope.properties.page != $event.target.id.replace("page_", "")){
           $scope.properties.content.length = 0
           $scope.task_ids = "";
           $scope.final_content = [];
           $scope.properties.page = $event.target.id.replace("page_", "");
        }

   }

  $scope.ceo_vision_js_task_doit = function() {
      var row = $scope.properties.selectedRow;
      var force_assign = "false";
      if(row.assigned_id == 0){
           force_assign = "true";
      }
      window.parent.parent.Drupal.gofast_workflows.ceo_vision_js_task_doit(row.id, row.processDefinititionSub.name+"/"+row.processDefinititionSub.version, "", row.name, force_assign);
  };

  $scope.ceo_vision_js_task_delegate = function() {
    var row = $scope.properties.selectedRow;
    window.parent.parent.Drupal.gofast_workflows.ceo_vision_js_task_delegate(row.rootCaseId, row.id, row.processDefinititionSub.name+"/"+row.processDefinititionSub.version, row.name);
  }

  $scope.ceo_vision_js_task_delete = function() {
      var row = $scope.properties.selectedRow;
      window.parent.parent.Drupal.gofast_workflows.ceo_vision_js_delete_task(row.rootCaseId);
  };


  $scope.ceo_vision_js_process_pageflow = function(){
     var row = $scope.properties.selectedRow;
     if(row.type == "kanban"){
         window.parent.parent.Gofast.processAjax(window.parent.parent.location.origin + "/node/" + row.nid);
     }else{
       if(typeof row.processHistory.persistenceId != "undefined"){
            window.parent.parent.Drupal.gofast_workflows.ceo_vision_js_process_pageflow("bdm", "", row.processHistory.persistenceId,"");
        }else{
            window.parent.parent.Drupal.gofast_workflows.ceo_vision_js_process_pageflow(row.processDefinitition.name, row.processDefinitition.version, row.rootCaseId, row.id);
        }
     }

  };

    function get_initiator_html_old(myTask){
      //if task is assigned to current user, display initiator picture, else display assigned
    var initiator_string = myTask.assigned_id;

      var url = "/api/user/picture?username="+initiator_string;
       $http.get(url).then(
                   function successCallback(response) {
                        myTask.actor = $sce.trustAsHtml(response.data.content);
                   }
            );

  }

  function get_initiator_html(myProcessHistory, myTask){
      //if task is assigned to current user, display initiator picture, else display assigned
      if( myTask.is_author == true){
        var initiator_string = myProcessHistory.initiator;
      }else{
         var initiator_string = myTask.assigneeId;
      }

      if(initiator_string == 0){
          initiator_string = myTask.actorId+"&actor=true";
      }
      var url = "/api/user/picture?username="+initiator_string;
       $http.get(url).then(
                   function successCallback(response) {
                      if( myTask.is_author == true){
                         var label_actor = $filter('gfTranslate')("label.started_by");
                         myTask.actor = $sce.trustAsHtml("<div style='clear:both;'>"+label_actor+"  : "+response.data.content+"</div>");
                        }else if (myTask.assigned_id === 0) {
                            var label_actor = $filter('gfTranslate')("label.free_to_take");
                            myTask.actor =$sce.trustAsHtml("<div style='clear:both;'>"+label_actor+"</div>");
                        }else{
                          var label_actor = $filter('gfTranslate')("label.assigned_to");
                          myTask.actor =$sce.trustAsHtml("<div style='clear:both;'>"+label_actor+"  : "+response.data.content+"</div>");
                      }

                   }
            );

  }

    function get_kanban_user_html(myTask, uid){
      var url = "/api/user/picture?uid="+uid;
       $http.get(url).then(
                   function successCallback(response) {
                        var label_actor = $filter('gfTranslate')("label.responsible");
                        myTask.actor =$sce.trustAsHtml("<div style='clear:both;'>"+label_actor+"  : "+response.data.content+"</div>");
                   }
            );

  }

 function get_documents_html_old(myVariable, myTask){
      var documents_string = myVariable.value.replace(/\;/g, ",");

      var url = "/api/node/links?nids="+documents_string;
       $http.get(url).then(
                   function successCallback(response) {
                        myTask.documents = $sce.trustAsHtml(response.data.content);
                   }
            );
  }


  function get_documents_html(myProcessCurrent, myTask){
      var documents_string = "";
      if(typeof myProcessCurrent.documents != "undefined"){
           myProcessCurrent.documents.forEach(function(nid) {
                documents_string = documents_string + nid +",";
          });
      }else{
          myProcessCurrent.contents.forEach(function(myProcessCurrentContent) {
              if(myProcessCurrentContent.type == "node"){
                  documents_string = documents_string + myProcessCurrentContent.content_value+",";
              }
          });
      }
      var url = "/api/node/links?nids="+documents_string;
       $http.get(url).then(
                   function successCallback(response) {
                        myTask.documents = $sce.trustAsHtml(response.data.content);
                   }
            );
  }

  function get_kanban_documents_html(documents, myTask){
      var documents_string = "";
      if(typeof documents != "undefined"){
           documents.forEach(function(nid) {
                documents_string = documents_string + nid +",";
          });
      }
      var url = "/api/node/links?nids="+documents_string;
       $http.get(url).then(
                   function successCallback(response) {
                        myTask.documents = $sce.trustAsHtml(response.data.content);
                   }
            );
  }

  function get_variable_can_delete_instance(myProcessCurrent, processInstance){
       can_delete = false;
       if(typeof myProcessCurrent != "undefined" && typeof myProcessCurrent.contents != "undefined"){
            myProcessCurrent.contents.forEach(function(myProcessCurrentContent) {
                  if(myProcessCurrentContent.type == "technical" && myProcessCurrentContent.name == "can_delete_instance"){
                      if(myProcessCurrentContent.content_value == "true"){
                          //check if current user is initiator
                          if($scope.properties.session.user_id.toString() == processInstance.startedBy.toString()){
                              can_delete = true;
                          }else{
                              can_delete = false
                          }
                      }else{
                         can_delete = false;
                      }
                  }
            });
       }
          return can_delete;
  }

  function get_deadline_html(processVariables, myTask){
      var d = new Date(myTask.expectedEndDate);
      var timestamp_now = new Date().getTime() / 1000;
      var timestamp = d.getTime() / 1000;

      if(timestamp_now > timestamp){
           var label_deadline = $filter('gfTranslate')("label.process_outdated");
           myTask.deadline_description = label_deadline;
           myTask.deadline_color = "#c0392b";
       }else if(timestamp - timestamp_now < 60*60*24){
           var label_deadline = $filter('gfTranslate')("label.process_soon_outdated");
           myTask.deadline_description = label_deadline;
           myTask.deadline_color = "#d35400";
       }else{
           myTask.deadline_description = "";
           myTask.deadline_color = "#2ecc71";
       }

    myTask.has_deadline = true;
    if(myTask.expectedEndDate === null || typeof myTask.expectedEndDate == "undefined"){
        label_deadline = $filter('gfTranslate')("label.process_has_no_deadline");
        myTask.deadline_description = label_deadline;
        myTask.expectedEndDate = " / ";
        myTask.has_deadline = false;
        myTask.deadline_color = "#5bc0de";   
    }
      var deadline_html = myTask.expectedEndDate;

      return deadline_html;
  }

  this.isClickable = function () {
    return $scope.properties.isBound('selectedRow');
  };

  this.selectRow = function (row) {
    if (this.isClickable()) {
      $scope.properties.selectedRow = row;
    }
  };

  this.isSelected = function(row) {
    return angular.equals(row, $scope.properties.selectedRow);
  };

},
      template: '<div class="table-responsive" style="overflow:visible;">\n    <div ng-if="!ctrl.isArray(final_content)" class="loader-autocomplete">&nbsp;</div>\n    <table class="table" ng-class="{\'table-hover\': ctrl.isClickable()}">\n        <thead>\n             <tr>\n                <th>\n                </th>\n            </tr>\n        </thead>\n\n         <tbody ng-if="ctrl.isArray(final_content)">\n            <tr style="cursor:auto;background-color:white;" ng-repeat="row in final_content" ng-click="ctrl.selectRow(row)" ng-class="">\n                <td>\n\n                <div class="task_in_todoliste" style="list-style: none;padding: 1px 2px;position: relative;" >\n                    <div class=\'task_in_todoliste\' style=\'padding-left:70px;\' title="{{row.deadline_description}}"><span style=\'background-color: {{row.deadline_color}};position: absolute;margin-left: -70px;margin-top: -6px;height: 57px;width: 60px;cursor:pointer;\' ng-click=\'ctrl.selectRow(row);ceo_vision_js_task_doit();\'><i class=\'fas fa-clock fa-3x\' style=\'color:white;margin-top:8px;margin-left:9px;\'></i></span>\n                    <div class="" style="background-color:white;margin:0px; padding:0px; /*width: inherit;*/">\n                        <div class="row">\n                            <span style="color:#777;font-weight: bold;width:35%;white-space: nowrap;overflow:hidden;text-overflow:ellipsis;-o-text-overflow:ellipsis;display: inline-block;" title=\'{{row.alt_title | gfTranslate}}\'>\n                                <i class="{{row.type_icon}}"></i>\n                                <span class="card-title">{{row.title}}</span>\n                            </span>\n                            <span style="color:#777;font-weight: bold;width:45%; max-width: 350px; white-space: nowrap;overflow:hidden;text-overflow:ellipsis;-o-text-overflow:ellipsis;display: inline-block;" title=\'{{row.displayDescription | gfTranslate}}\'>\n                                <i class="far fa-flag"></i>\n                                <span class="card-subtitle mb-2 text-muted">{{row.displayDescription | gfTranslate}}</span>\n                            </span>\n                            <div style="float:right;">\n                               <span ng-bind-html="row.actor" class="ng-binding ng-scope card-text actor_container" style="display: inline-block;clear:both;"></span>\n                            </div>\n                        </div>\n                        <div class="row">\n                            <div>\n                                <div class="deadline_box_in_rapide_todoliste" style="float:left;width:35%;max-height:22px;overflow:hidden;text-overflow:ellipsis;-o-text-overflow:ellipsis;display: inline-block;">\n                                   <i ng-if="row.has_process_end_date" class="fas fa-calendar-alt"></i> <span ng-if="row.has_process_end_date" style="font-weight: bold;" title=\'{{"label.process_end_date" | gfTranslate}}\'>{{row.process_end_date|date:"dd/MM/yyyy"}}</span>\n                                </div>\n                                <div class="deadline_box_in_rapide_todoliste" style="font-weight:bold;float:left;width:15%;px;max-height:22px;overflow:hidden;text-overflow:ellipsis;-o-text-overflow:ellipsis;display: inline-block;">\n                                   <i ng-if="row.has_deadline" class="far fa-clock" /*style="color:#337ab7;"*/></i> <span ng-if="row.has_deadline" style="color:{{row.deadline_color}};" title=\'{{"label.process_deadline" | gfTranslate}}\'>{{row.deadline|date:"dd/MM/yyyy"}}</span>\n                                </div>\n\n                                <div class="deadline_box_in_rapide_todoliste" style="float:left;width:40%;max-height:22px;margin-left:-9px;overflow:hidden;word-break:break-all;">\n                                     <div ng-bind-html="row.documents" class="ng-binding ng-scope card-text document_container"></div>\n                                </div>\n                                <div id="wf-buttons" style="float: right;margin-right: 0px;">\n                                    <span ng-if="row.is_eligible" class="gofast_workflows_title_task_doit" style="cursor:pointer;" ng-click=\'ctrl.selectRow(row);ceo_vision_js_task_doit();\' title=\'{{"label.process_doit" | gfTranslate}}\'>\n                                        <button type="button" class="btn btn-default wf-button wf-button-green" style="padding:1px 6px;width:22px;color: #2ecc71;">\n                                            <span class="fas fa-play gofast_wf_link"></span>\n                                        </button>\n                                    </span>\n                                    <span ng-if="row.can_delegate_task" class="gofast_workflows_title_task_doit" style="cursor:pointer;" ng-click=\'ctrl.selectRow(row);ceo_vision_js_task_delegate();\' title=\'{{"label.process_delegate" | gfTranslate}}\'>\n                                        <button type="button" class="btn btn-default wf-button wf-button-orange" style="padding:1px 6px;color: #ffa800;">\n                                            <span class="fas fa-users-cog gofast_wf_link"></span>\n                                        </button>\n                                    </span>\n                                    <span style="cursor:pointer;" ng-click=\'ctrl.selectRow(row);ceo_vision_js_process_pageflow();\'>\n                                        <button type="button" class="btn btn-default wf-button wf-button-blue" style="padding:1px 6px;width:22px;color: #337ab7;">\n                                            <span class="fas fa-info gofast_wf_link"></span>\n                                        </button>\n                                    </span>\n                                    <span ng-if="row.can_delete" class="gofast_workflows_title_task_doit" style="cursor:pointer;" ng-click=\'ctrl.selectRow(row);ceo_vision_js_task_delete();\' title=\'{{"label.process_delete" | gfTranslate}}\'>\n                                        <button type="button" class="btn btn-default wf-button wf-button-red" style="padding:1px 4px;width:22px;color: red;">\n                                            <span class="fas fa-trash gofast_wf_link"></span>\n                                        </button>\n                                    </span>\n                        </div>\n                            </div>\n                        </div>\n                    </div>\n                    <div style="clear:both;"></div>\n                </div>\n                </td>\n            </tr>\n        </tbody>\n    </table>\n    <div class="btn-group" style="margin: 0 auto;display: table;">\n        <button page="{{page.number}}" id="page_{{page.number}}" ng-click=\'change_page($event);\' ng-repeat="page in pagination" type="button" class="btn btn-default {{page.btn_class}}" aria-haspopup="true" aria-expanded="false" style="background-color:#fff;color:#337ab7;">\n           {{page.label}}\n        </button>\n    </div>\n</div>\n\n<style>\n.loader-autocomplete{\n    border:3px solid #f3f3f3;\n    border-radius: 50%;\n    border-top: 3px solid #3498db;\n    border-bottom: 3px solid #3498db;\n    width:50px;\n    height:50px;\n    -webkit-animation: spin 2s linear infinite;\n    animation: spin-loader 2s linear infinite;\n    margin: 0 auto;\n\n}\n\n@keyframes spin-loader{\n    0% {transform: rotate(0deg);}\n    100% {transform: rotate(360deg);}\n}\n\n.btn_active{\n    background-color:#337ab7!important;\n    color:#fff!important;\n}\n\n.table{\n    margin-bottom:2px!important;\n}\n</style>'
    };
  });
