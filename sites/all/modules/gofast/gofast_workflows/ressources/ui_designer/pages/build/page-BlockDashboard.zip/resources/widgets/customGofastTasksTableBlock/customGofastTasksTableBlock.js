(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customGofastTasksTableBlock', function() {
    return {
      controllerAs: 'ctrl',
      controller: function PbTableCtrl($scope, $http, $sce, $filter) {
     $scope.pagination = [];
     
     
    
     $scope.task_ids = "";
     $scope.$watch("properties.content", function(){
          if(typeof $scope.properties.content == "undefined"){
              return;
          }
         $scope.final_content = [];
         $scope.build_pagination();
         $scope.properties.content.forEach(function(myTaskContent) {
             $scope.task_ids = typeof myTaskContent.id !== "undefined" ? $scope.task_ids+myTaskContent.id+"-" : $scope.task_ids+"kanban-";
         });
         
         $http.get("/bonita/API/extension/getTasksAllInfos?taskids="+$scope.task_ids).then( 
           function successCallback(response) {
           var i = 0;
            response.data.response.content.forEach(function(myTask) {
                    if(typeof myTask.type !== "undefined" && myTask.type == "kanban"){
                        var kanban_element = $scope.properties.content[i];  
                        myTask.title = kanban_element.title;
                       
                        if(kanban_element.closest_deadline_color_indicator == "deadline-nearly-reached"){
                            myTask.deadline_color = "#d35400";
                        }else if(kanban_element.closest_deadline_color_indicator == "deadline-reached"){
                            myTask.deadline_color = "#c0392b";
                        }else if(kanban_element.closest_deadline_color_indicator == 'deadline-reached-off' || kanban_element.closest_deadline_color_indicator == 'deadline-nearly-reached-off' ){
                            myTask.deadline_color = "#b5b5c3";
                        }else{
                            myTask.deadline_color = "#2ecc71";
                        }
                        
                        if(typeof kanban_element.closest_deadline !== "undefined" && kanban_element.closest_deadline !== ""){
                            myTask.deadline = kanban_element.closest_deadline;
                            myTask.has_deadline = true;
                        }else{
                            myTask.end_date = "  ";
                            myTask.deadline = "  ";
                        }
                        
						myTask.deadline_timestamp = kanban_element.closest_deadline_timestamp;
                        myTask.actor = get_kanban_user_html(myTask, kanban_element.person_in_charge);
                        myTask.start_date = kanban_element.created_date;
                        myTask.displayDescription = $filter('gfTranslate')("label.completed_at") + " " + kanban_element.progress + "%";
                        myTask.type_icon = "fa-trello";
                        myTask.nid = kanban_element.nid;
                        myTask.documents = get_kanban_documents_html(kanban_element.attachments, myTask);
                        myTask.is_kanban = true;
                    }else{
                        myTask.title = myTask.processHistory.title;
    
                        if($scope.properties.session.user_id == myTask.assigned_id){
                            myTask.is_author = true;
                        }else{
                            myTask.is_author = false;
                        }
                       
                        myTask.deadline_timestamp = new Date(myTask.processCurrent.end_date).getTime()/1000;
                        myTask.actor = get_initiator_html(myTask.processHistory, myTask);
                        myTask.documents = get_documents_html(myTask.processCurrent, myTask);
                        myTask.deadline = get_deadline_html(myTask.processCurrent,myTask);
                        myTask.start_date = myTask.processHistory.start_date;
                        myTask.processName = myTask.processInstance.name;
                        myTask.processVersion = myTask.processInstance.version;
                        myTask.processId = myTask.processInstance.id;
                        myTask.type_icon = "fa-cogs";
                    }
        
                    $scope.final_content.push(myTask);
                    i++;
           });
           
           //Sort deadline for both process and kanban tasks
		   $scope.final_content.sort(function(a, b){
			   return a.deadline_timestamp - b.deadline_timestamp;
		   });
           
        });
   
     });
        

  this.isArray = Array.isArray;
  
    $scope.build_pagination = function(){
          $scope.$watch("properties.pageCount", function(){
          if(typeof $scope.properties.pageCount == "undefined"){
              return;
          }
          $scope.pagination = [];
          var results_count = typeof $scope.properties.pageCount == "object" ? $scope.properties.pageCount.getResponseHeader('Content-Range').replace("0-0/", "") : $scope.properties.pageCount;
          var number_page = results_count / 4;
          
          var i;
          for (i = 0; i < number_page; i++) {
                page_label = i + 1;
                if(i == $scope.properties.page){
                    var btn_class = "active"; //"btn_active";
                }else{
                    var btn_class = "";
                }
                var my_page_object = {number:i, label:page_label, btn_class:btn_class}
                $scope.pagination.push(my_page_object);
           }
        });
        
  }
  
  
   $scope.change_page = function($event){
       
       var request_page, pagination_first, pagination_last ;
	  
       if($event.target.tagName == 'I'){
           request_page = $event.target.parentNode.parentNode.id.replace("page_", "");
		   pagination_first = $event.target.parentNode.parentNode.parentNode.firstElementChild;
		   pagination_last = $event.target.parentNode.parentNode.parentNode.lastElementChild;
       }else{
           request_page = $event.target.id.replace("page_", "");
		   pagination_first = $event.target.parentNode.parentNode.firstElementChild;
		   pagination_last = $event.target.parentNode.parentNode.lastElementChild;
       }

	   var results_count = typeof $scope.properties.pageCount == "object" ? $scope.properties.pageCount.getResponseHeader('Content-Range').replace("0-0/", "") : $scope.properties.pageCount;
       var number_page = Math.ceil(results_count / 4);

	   if (request_page == "first"){
		   request_page = 0;
	   }else if (request_page == "last"){
		   request_page = number_page - 1 ;
	   }
	   
	   if(number_page > 1){
	        
    	   //manage display og first and last button in pagination
    	   if(request_page == number_page - 1){
    		   pagination_last.style.cssText = 'display:none;';
    		   pagination_first.style.cssText ='';
    		   
    	   }else if(request_page == 0){
    	       //hide last and display first btn
    		   pagination_first.style.cssText ='display:none;';
    		   pagination_last.style.cssText= '';
    		   
    	   }else{
    	       pagination_first.style.cssText ='';
		       pagination_last.style.cssText= '';
    	   }
	        
	   }else{
	       pagination_first.style.cssText='display:none;';
		   pagination_last.style.cssText= 'display:none;';
	   }
		   

       if($scope.properties.page != request_page){
           $scope.properties.content.length = 0
           $scope.task_ids = "";
           $scope.final_content = [];
           $scope.properties.page = request_page;
        }
       
   }

  $scope.ceo_vision_js_task_doit = function() {
      var row = $scope.properties.selectedRow;
      var force_assign = "false";
      if(row.assigned_id == 0){
           force_assign = "true";
      }
      window.parent.parent.Drupal.gofast_workflows.ceo_vision_js_task_doit(row.id, row.processDefinititionSub.name+"/"+row.processDefinititionSub.version, "", row.name, force_assign);
  };

  $scope.ceo_vision_js_process_pageflow = function(){
     var row = $scope.properties.selectedRow;
     if(row.type == "kanban"){
         window.parent.parent.Gofast.processAjax(window.parent.parent.location.origin + "/node/" + row.nid);
     }else{
        window.parent.parent.Drupal.gofast_workflows.ceo_vision_js_process_pageflow("bdm", "", row.processHistory.persistenceId,"");
     }

  };
  
    function get_initiator_html_old(myTask){
      //if task is assigned to current user, display initiator picture, else display assigned
    var initiator_string = myTask.assigned_id;
  
      var url = "/api/user/picture?username="+initiator_string;
       $http.get(url).then( 
                   function successCallback(response) {
                        myTask.actor = $sce.trustAsHtml(response.data.content);
                   }    
            ); 
     
  }

  function get_initiator_html(myProcessHistory, myTask){
      //if task is assigned to current user, display initiator picture, else display assigned
      if( myTask.is_author == true){
        var initiator_string = myProcessHistory.initiator;
      }else{
         var initiator_string = myTask.assigneeId; 
      }
  
      if(initiator_string == 0){
          initiator_string = myTask.actorId+"&actor=true";
      }
      var url = "/api/user/picture?username="+initiator_string;
       $http.get(url).then( 
                   function successCallback(response) {
                      if( myTask.is_author == true){
                         var label_actor = $filter('gfTranslate')("label.started_by");
                         myTask.actor = $sce.trustAsHtml("<div style='clear:both;'>"+label_actor+"  : "+response.data.content+"</div>");
                      }else{
                          var label_actor = $filter('gfTranslate')("label.assigned_to");
                          myTask.actor =$sce.trustAsHtml("<div style='clear:both;'>"+label_actor+"  : "+response.data.content+"</div>");
                      }
                      
                   }    
            ); 

  }
  
    function get_kanban_user_html(myTask, uid){
      var url = "/api/user/picture?uid="+uid;
       $http.get(url).then( 
                   function successCallback(response) {
                        var label_actor = $filter('gfTranslate')("label.responsible");
                        myTask.actor =$sce.trustAsHtml("<div style='clear:both;'>"+label_actor+"  : "+response.data.content+"</div>"); 
                   }
            ); 

  }
  
 function get_documents_html_old(myVariable, myTask){
      var documents_string = myVariable.value.replace(/\;/g, ",");
 
      var url = "/api/node/links?nids="+documents_string;
	  if(documents_string.length > 0){
       $http.get(url).then( 
                   function successCallback(response) {
                        myTask.documents = $sce.trustAsHtml(response.data.content);
                   }    
            );
	  }else{
		   myTask.documents = null;
	  } 
  }
  

  function get_documents_html(myProcessCurrent, myTask){
      var documents_string = "";
      if(typeof myProcessCurrent.documents != "undefined"){
           myProcessCurrent.documents.forEach(function(nid) {
                documents_string = documents_string + nid +",";
          });
      }else{
          myProcessCurrent.contents.forEach(function(myProcessCurrentContent) {
              if(myProcessCurrentContent.type == "node"){
                  documents_string = documents_string + myProcessCurrentContent.content_value+",";
              }
          });
      }
      var url = "/api/node/links?nids="+documents_string;
      if(documents_string.length > 0){
            $http.get(url).then( 
                   function successCallback(response) {
                        myTask.documents = $sce.trustAsHtml(response.data.content);
                   }    
            ); 
       }else{
            myTask.documents = null;
       }
  }
  
  function get_kanban_documents_html(documents, myTask){
      var documents_string = "";
      if(typeof documents != "undefined"){
           documents.forEach(function(nid) {
                documents_string = documents_string + nid +",";
          });
      }
      var url = "/api/node/links?nids="+documents_string;
      if(documents_string.length > 0){
            $http.get(url).then( 
                   function successCallback(response) {
                        myTask.documents = $sce.trustAsHtml(response.data.content);
                   }    
            );
      }else{
          myTask.documents =null;
      }
  }
  
  function get_deadline_html(processVariables, myTask){
      var d = new Date(processVariables.end_date);
      var timestamp_now = new Date().getTime() / 1000;
      var timestamp = d.getTime() / 1000;
      
      if(timestamp_now > timestamp){
           var label_deadline = $filter('gfTranslate')("label.process_outdated");
           myTask.deadline_description = label_deadline;
           myTask.deadline_color = "#c0392b";
       }else if(timestamp - timestamp_now < 60*60*24){
           var label_deadline = $filter('gfTranslate')("label.process_soon_outdated");
           myTask.deadline_description = label_deadline;
           myTask.deadline_color = "#d35400";
       }else{
           myTask.deadline_description = "";
           myTask.deadline_color = "#2ecc71";
       }
      
    myTask.has_deadline = true;
    if(processVariables.end_date === null || typeof processVariables.end_date == "undefined"){
        processVariables.end_date = " / ";
        myTask.has_deadline = false;
        myTask.deadline_color = "#5bc0de";
        
    }
      var deadline_html = processVariables.end_date;
    
      return deadline_html;
  }

  this.isClickable = function () {
    return $scope.properties.isBound('selectedRow');
  };

  this.selectRow = function (row) {
    if (this.isClickable()) {
      $scope.properties.selectedRow = row;
    }
  };

  this.isSelected = function(row) {
    return angular.equals(row, $scope.properties.selectedRow);
  };

}
,
      template: '<div class="table-responsive" style="overflow:visible; margin-bottom: 60px;">\n    <div ng-if="!ctrl.isArray(final_content)" class="loader-autocomplete">&nbsp;</div>\n    <table class="table" ng-class="{\'table-hover\': ctrl.isClickable()}">        \n         <tbody ng-if="ctrl.isArray(final_content)">\n            <tr ng-repeat="row in final_content" ng-click="ctrl.selectRow(row)" ng-class="{\'info\': ctrl.isSelected(row)}">\n                <td>\n                    \n                <div class="task_in_todoliste" style="background-color: #f9f9f9;border: 1px solid #eee;list-style: none;padding: 6px 9px;position: relative;" >\n                    <div class=\'task_in_todoliste\' style=\'padding-left:35px;\' title="{{row.deadline_description}}"><span style=\'background-color: {{row.deadline_color}};position: absolute;margin-left: -40px;margin-top: -3px;height: 33px;width: 35px;\'><i class=\'fas fa-clock fa-2x\' style=\'color:white;margin-top:3px;margin-left:4px;\'></i></span>\n                    <div style="float:right;">\n                       <span ng-if="row.is_eligible" class="gofast_workflows_title_task_doit" style="cursor:pointer;" ng-click=\'ctrl.selectRow(row);ceo_vision_js_task_doit();\' title=\'{{"label.process_doit" | gfTranslate}}\'>\n                            <button type="button" class="btn btn-default wf-button wf-button-green" style="padding:1px 6px;width:22px;color: #2ecc71;">\n                                <span class="fas fa-play gofast_wf_link"></span>\n                            </button>\n                        </span>\n						<span ng-if="row.is_kanban" style="cursor:pointer;" ng-click=\'ctrl.selectRow(row);ceo_vision_js_process_pageflow();\'>\n                            <button type="button" class="btn btn-default wf-button wf-button-blue" style="padding:1px 6px;width:22px;color: #337ab7;">\n                                <span class="fas fa-info gofast_wf_link"></span>\n                            </button> \n                        </span>\n                    </div>\n                    <div style="padding-left:20px;">\n                        <div class="row">\n                            <span ng-if="!row.is_kanban" style="color:#337ab7;font-weight: bold;width:165px;white-space: nowrap;overflow:hidden;text-overflow:ellipsis;-o-text-overflow:ellipsis;display: inline-block;" title="{{row.displayDescription | gfTranslate}}">\n                                <i class="fas fa-cogs" style="color:#777"></i>\n                                <span class="card-subtitle mb-2 text-muted">{{row.displayDescription | gfTranslate}}</span>\n                            </span>\n							<span ng-if="row.is_kanban" style="color:#337ab7;width:165px;white-space: nowrap;overflow:hidden;text-overflow:ellipsis;-o-text-overflow:ellipsis;display: inline-block;" title=\'{{row.title}}\'>\n                                <i class="fab {{row.type_icon}}" style="color:#777"></i>\n                                <span class="card-title" style="color:#777; font-weight: bold;">{{row.title}}</span>\n                            </span>\n							<div class="deadline_box_in_rapide_todoliste file_list" style="float:right;max-width:350px;max-height:22px;margin-right:20px;margin-top:2px;overflow:hidden;word-break:break-all;">\n                                     <div ng-bind-html="row.documents" class="ng-binding ng-scope card-text document_container"></div>\n                            </div>\n                        </div>\n                    </div>\n                    <div style="clear:both;"></div>\n                </div>\n                </td>\n            </tr>\n        </tbody>\n    </table>\n    \n    <nav class="text-center mt-6 dashboard-pagination-bottom">\n    	<ul class="pagination pagination-sm justify-content-center" id="bookmark_pager_content">\n    	    \n    	    <li style="display: none;">\n    			<a href="#" id="page_first" ng-click=\'change_page($event);\' class="btn btn-icon btn-sm btn-light-primary mr-2 my-1 first_link" aria-label="First">\n    				<span aria-hidden="false">\n    					<i class="fas fa-angle-double-left" ></i>\n    				</span>\n    			</a>\n    		</li>\n    		<li page="{{page.number}}" ng-repeat="page in pagination">\n    			<a href="#" id="page_{{page.number}}" ng-click=\'change_page($event);\' class="btn btn-icon btn-sm border-0 btn-hover-primary mr-2 my-1 page_link  {{page.btn_class}}" style="">\n    			    {{page.label}}\n    			</a>\n    		</li>\n    		<li>\n    			<a href="#" id="page_last" ng-click=\'change_page($event);\' class="btn btn-icon btn-sm btn-light-primary mr-2 my-1 last_link" aria-label="Last">\n    				<span aria-hidden="false">\n    					<i class="fas fa-angle-double-right"></i>\n    				</span>\n    			</a>\n    		</li>\n    	</ul>\n    </nav>\n    \n    \n    \n    \n    \n</div>\n\n<style>\n.loader-autocomplete{\n    border:3px solid #f3f3f3;\n    border-radius: 50%;\n    border-top: 3px solid #3498db;\n    border-bottom: 3px solid #3498db;\n    width:50px;\n    height:50px;\n    -webkit-animation: spin 2s linear infinite;\n    animation: spin-loader 2s linear infinite;\n    margin: 0 auto;\n\n}\n\n@keyframes spin-loader{\n    0% {transform: rotate(0deg);}\n    100% {transform: rotate(360deg);}\n}\n\n.btn_active{\n    background-color:#337ab7!important;\n    color:#fff!important;\n}\n\n.btn:not(:disabled):not(.disabled):active, .btn:not(:disabled):not(.disabled).active {\n  box-shadow: none;\n}\n\n.btn.btn-light-primary.last_link i, .btn.btn-light-primary.first_link i {\n	font-size: 1.3em;\n}\n\n.btn.btn-light-primary:hover:not(.btn-text):not(:disabled):not(.disabled), .btn.btn-light-primary:focus:not(.btn-text), .btn.btn-light-primary.focus:not(.btn-text) {\n  color: #fff;\n  background-color: #3699ff;\n  border-color: transparent;\n}\n\n.btn i {\n  font-size: 1.3rem;\n  padding-right: .35rem;\n  vertical-align: middle;\n  line-height: 1;\n  display: inline-flex;\n}\n\n.btn:not(:disabled):not(.disabled) {\n\n    cursor: pointer;\n\n}\n.btn.btn-light-primary {\n    color: #3699ff;\n    background-color: #e1f0ff;\n    border-color: transparent;\n\n}\n\n.table{\n    margin-bottom:2px!important;\n}\n\n.btn.btn-hover-primary:not(:disabled):not(.disabled).active{\n    color: #fff !important;\n    background-color: #3699ff !important;\n    border-color: #3699ff !important;\n}\n\n.pagination {\n  display: flex;\n  padding-left: 0;\n  list-style: none;\n  border-radius: .42rem;\n  margin: 20px 0;\n  font-size: 1.3rem;\n}\n\n.pagination > li {\n  display: inline;\n}\n\n\n.pagination-sm > li:first-child > a, .pagination-sm > li:first-child > span {\n  border-top-left-radius: 3px;\n  border-bottom-left-radius: 3px;\n  margin-left: 0;\n}\n\n.pagination > li > a, .pagination > li > span {\n  position: relative;\n  float: left;\n  padding: 6px 12px;\n  margin-left: -1px;\n  line-height: 1.42857143;\n  color: #337ab7;\n  text-decoration: none;\n  background-color: #fff;\n  border: 1px solid #ddd;\n  margin-right: 0.5rem;\n  margin-top: 0.25rem;\n  margin-bottom: 0.25rem;\n  box-shadow: none;\n  border: 0;\n}\n\n\n.btn.btn-hover-primary:hover:not(.btn-text):not(:disabled):not(.disabled), .btn.btn-hover-primary:focus:not(.btn-text), .btn.btn-hover-primary.focus:not(.btn-text) {\n  color: #fff !important;\n  background-color: #3699ff !important;\n  border-color: #3699ff !important;\n}\n\n.btn:hover:not(.btn-text), .btn:focus:not(.btn-text), .btn.focus {\n  transition: color .15s ease,background-color .15s ease,border-color .15s ease,box-shadow .15s ease;\n}\n\n.btn.btn-icon {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  padding: 0;\n  height: calc(1.5em + 1.3rem + 2px);\n  width: calc(1.5em + 1.3rem + 2px);\n}\n\n.dashboard-pagination-bottom, .view-display-id-upcoming_meetings .text-center {\n  position: absolute;\n  bottom: 0;\n  left: 50%;\n  transform: translateX(-50%);\n  font-size: 13px !important;\n}\n\n.pagination-sm > li > a, .pagination-sm > li > span {\n  padding: 5px 10px;\n  font-size: 12px;\n}\n\n.btn-sm, .btn-group-sm > .btn {\n  padding: 5px 10px;\n  font-size: 12px;\n  line-height: 1.5;\n  border-radius: 3px;\n}\n\n.text-center {\n  text-align: center !important;\n}\n\n\n</style>'
    };
  });
