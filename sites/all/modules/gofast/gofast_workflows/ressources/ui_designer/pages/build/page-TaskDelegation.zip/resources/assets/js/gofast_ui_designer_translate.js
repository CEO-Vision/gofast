!function(){
	var app = angular.module('bonitasoft.ui');

	app.filter('gfTranslate', function () {
	    //Retrieve URL parameters
        let urlParams = new URLSearchParams(document.location.search);
        let taskName = urlParams.get("taskName");
        //Get the langcode from the URL
        let langcode = urlParams.get("locale");
        return function (item) {
			if(typeof langcode == "undefined"){
				langcode = "en";
			}
			//Declare localizations
			var localizations = {
				"en" : {
                    "header.title": "Delegate the task " + atob(taskName),
					"placeholder.target": "To whom do you wish to delegate the task?",
					"button.submit" : "Submit",
					"text.delegation_warning": "Once the task is delegated, you will not be able to take it unless the new assignee delegates it back to you.",
				},
				"fr" : {
                    "header.title": "Déléguer la tâche " + atob(taskName),
					"placeholder.target": "À qui souhaitez-vous déléguer la tâche ?",
                    "button.submit" : "Envoyer",
					"text.delegation_warning": "Une fois la tâche déléguée, vous ne pourrez pas la reprendre à moins que le nouvel attributaire ne vous la délègue à nouveau.",
				},
				"nl" : {
                    "header.title": "De taak " + atob(taskName) + " delegeren",
					"placeholder.target": "Aan wie wil je de taak delegeren?",
					"button.submit" : "Voorleggen",
					"text.delegation_warning": "Als de taak eenmaal is gedelegeerd, kun je deze niet meer overnemen, tenzij de nieuwe opdrachtnemer de taak weer aan jou delegeert.",
				},
			};
			
			//Return the translated content
			if(typeof localizations[langcode][item] !== "undefined"){
				return localizations[langcode][item];
			}else if(typeof localizations[langcode]["en"] !== "undefined"){
				return localizations[langcode]["en"];
			}else{
				return item;
			}
		};
	});
}();