(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customGofastProcessTable', function() {
    return {
      controllerAs: 'ctrl',
      controller: function PbTableCtrl($scope, $http, $sce, $filter) {
     $scope.pagination = [];
     
     
    
     $scope.process_ids = "";
     $scope.$watch("properties.content", function(){
          if(typeof $scope.properties.content == "undefined"){
              return;
          }
         $scope.final_content = [];
         $scope.build_pagination();

         $scope.properties.content.forEach(function(myProcessContent) {
            $scope.task_ids = $scope.task_ids+myProcessContent.id+"-";
             
            //Fill task content
            var myTask = {}
            myTask.id = myProcessContent.id;
            myTask.start = myProcessContent.start;
            myTask.state = myProcessContent.state;
            myTask.deadline = myProcessContent.deadline;
            myTask.title = myProcessContent.title;
            myTask.type = myProcessContent.type;
            myTask.startedby = myProcessContent.startedby;
            myTask.todo_count = myProcessContent.todo_count;
            myTask.done_count = myProcessContent.done_count;
			myTask = set_deadline_color(myProcessContent, myTask);
			myTask.actor = get_initiator_html(myTask.processHistory, myTask);
			myTask.hid = myProcessContent.hid;
			myTask.documents = myProcessContent.documents;
			
			if(myTask.state == "finished"){
			    myTask.icon = "fa-check";
			    myTask.margin = "1";
			}else{
			    myTask.icon = "fa-clock-o";
			    myTask.margin = "3";
			}
			
            //Push content to final array
            $scope.final_content.push(myTask);
         });
   
     });
        

  this.isArray = Array.isArray;
  
    $scope.build_pagination = function(){
          $scope.$watch("properties.pageCount", function(){
              
          if(typeof $scope.properties.pageCount == "undefined"){
              return;
          }
          $scope.pagination = [];
          var results_count = $scope.properties.pageCount.split("/")[1];
          var number_page = results_count / 10;
          
          var i;
          for (i = 0; i < number_page; i++) {
                if(i == (parseInt($scope.properties.page)-1)){
                    var my_page_object = {number:i, label:"<", btn_class:""}
                    $scope.pagination.push(my_page_object);
                }else if(i == (parseInt($scope.properties.page)+1) && $scope.properties.content.length == 10){
                    var my_page_object = {number:i, label:">", btn_class:""}
                    $scope.pagination.push(my_page_object);
                }else if(i == $scope.properties.page){
                    var my_page_object = {number:i, label:i+1, btn_class:"btn_active"}
                    $scope.pagination.push(my_page_object);
                }
           }
        });
        
  }
  
  
   $scope.change_page = function($event){
       if($scope.properties.page != $event.target.id.replace("page_", "")){
           $scope.properties.content.length = 0
           $scope.task_ids = "";
           $scope.final_content = [];
           $scope.properties.page = $event.target.id.replace("page_", "");
        }
       
   }
   
function get_initiator_html(myProcessHistory, myTask){
      if(myTask.startedby > 0){
          var url = "/api/user/picture?username="+myTask.startedby + "&with_name=1";
           $http.get(url).then( 
                       function successCallback(response) {
                            var label_actor = $filter('gfTranslate')("label.started_by");
                            myTask.actor = $sce.trustAsHtml("<div style='clear:both;'>"+response.data.content+"</div>");
                       }    
                ); 
      }else{
          return $filter('gfTranslate')("label.started_auto");
      }

}
   
   function set_deadline_color(processVariables, myTask){
        myTask.has_deadline = true;
        if(processVariables.deadline === null || typeof processVariables.deadline == "undefined" || processVariables.deadline == ""){
            processVariables.deadline = " / ";
            myTask.has_deadline = false;
            myTask.deadline_color = "#5bc0de";
        }else{
            var d = new Date(processVariables.deadline);
            var timestamp_now = new Date().getTime() / 1000;
            var timestamp = d.getTime() / 1000;
              
            if(timestamp_now > timestamp){
                myTask.deadline_color = "#c0392b";
            }else if(timestamp - timestamp_now < 60*60*24){
                myTask.deadline_color = "#d35400";
            }else{
                myTask.deadline_description = "";
                myTask.deadline_color = "#2ecc71";
            }
        }
        
        if(myTask.state == "finished"){
            myTask.deadline_color = "#2ecc71";
        }
      return myTask;
  }
  
  this.isClickable = function () {
    return $scope.properties.isBound('selectedRow');
  };

  this.selectRow = function (row) {
    if (this.isClickable()) {
      $scope.properties.selectedRow = row;
      window.parent.parent.Gofast.gofast_workflow_show_details(row.id, row.type, row.title, row.hid, row.documents);
    }
  };

  this.isSelected = function(row) {
    return angular.equals(row, $scope.properties.selectedRow);
  };

}
,
      template: '<div class="table-responsive" style="overflow:visible;">\n    <div ng-if="!ctrl.isArray(final_content)" class="loader-autocomplete">&nbsp;</div>\n    <table class="table" ng-class="{\'table-hover\': ctrl.isClickable()}">\n        <thead>\n             <tr>\n                <th>\n                </th>\n            </tr>\n        </thead>\n        \n         <tbody ng-if="ctrl.isArray(final_content)">\n            <tr ng-repeat="row in final_content" ng-click="ctrl.selectRow(row)" ng-class="{\'info\': ctrl.isSelected(row)}">\n                <td>\n                    \n                <div class="task_in_todoliste" style="background-color: #f9f9f9;border: 1px solid #eee;list-style: none;padding: 17px 9px 12px;position: relative;" >\n                    <div class=\'task_in_todoliste\' style=\'padding-left:70px;\'>\n						<span style=\'background-color: {{row.deadline_color}};position: absolute;margin-left: -70px;margin-top: -5px;height: 30px;width: 30px;\'>\n							<i class=\'fa {{row.icon}} fa-2x\' style=\'color:white;margin-top:1px;margin-left:{{row.margin}}px;\'></i>\n					</span>\n                    <div style="float:right;">\n                       <span ng-bind-html="row.actor" class="ng-binding ng-scope card-text actor_container" style="display: inline-block;clear:both;"></span> \n                    </div>\n                    <div style="padding-left:20px;">\n                        <div class="row">\n                            <span style="color:#777;font-weight: bold;width:22%;white-space: nowrap;overflow:hidden;text-overflow:ellipsis;-o-text-overflow:ellipsis;display: inline-block;" title=\'{{"label.process_title" | gfTranslate}}\'>\n                                <i class="fa fa-cogs"></i>\n                                <span class="card-title">{{row.title}}</span>\n                            </span>\n                            <span style="color:#777;font-weight: bold;width:22%;white-space: nowrap;overflow:hidden;text-overflow:ellipsis;-o-text-overflow:ellipsis;display: inline-block;">\n                                <i class="fa fa-code-fork"></i>\n                                <span class="card-subtitle mb-2 text-muted">{{row.type | gfTranslate}}</span>\n                            </span>\n							<span style="color:#337ab7;font-weight: bold;width:13%;white-space: nowrap;overflow:hidden;text-overflow:ellipsis;-o-text-overflow:ellipsis;display: inline-block;" title=\'{{"label.tasks" | gfTranslate}} {{row.todo_count}} {{"label.todo" | gfTranslate}}, {{row.done_count}} {{"label.done" | gfTranslate}}\'>\n                                <span class="card-subtitle mb-2 text-muted">{{row.todo_count}} <i class="fa fa-flag-o"></i> | {{row.done_count}} <i class="fa fa-check-square-o"></i></span>\n                            </span>\n							<div class="deadline_box_in_rapide_todoliste" style="max-width:125px;max-height:22px;overflow:hidden;text-overflow:ellipsis;-o-text-overflow:ellipsis;display: inline-block;">\n                                <i class="fa fa-calendar"></i> <span title=\'{{"label.process_start_date" | gfTranslate}}\'>{{row.start|date:"dd/MM/yyyy"}}</span>\n                            </div>\n                            <div class="deadline_box_in_rapide_todoliste" style="font-weight:bold;cursor:pointer;width:125px;text-align:center;px;max-height:22px;overflow:hidden;text-overflow:ellipsis;-o-text-overflow:ellipsis;display: inline-block;">\n                                <i ng-if="row.has_deadline" class="fa fa-clock-o" style="color:{{row.deadline_color}};"></i> <span style="color:{{row.deadline_color}};" title=\'{{"label.process_deadline" | gfTranslate}}\'>{{row.deadline|date:"dd/MM/yyyy"}}</span>\n                            </div>\n                        </div>\n                    </div>\n                    <div style="clear:both;"></div>\n                </div>\n                </td>\n            </tr>\n        </tbody>\n    </table>\n    <div class="btn-group" style="margin: 0 auto;display: table;">\n        <button page="{{page.number}}" id="page_{{page.number}}" ng-click=\'change_page($event);\' ng-repeat="page in pagination" type="button" class="btn btn-default {{page.btn_class}}" aria-haspopup="true" aria-expanded="false" style="background-color:#fff;color:#337ab7;">\n           {{page.label}}\n        </button>\n    </div>\n</div>\n\n<style>\n.loader-autocomplete{\n    border:3px solid #f3f3f3;\n    border-radius: 50%;\n    border-top: 3px solid #3498db;\n    border-bottom: 3px solid #3498db;\n    width:50px;\n    height:50px;\n    -webkit-animation: spin 2s linear infinite;\n    animation: spin-loader 2s linear infinite;\n    margin: 0 auto;\n\n}\n\n@keyframes spin-loader{\n    0% {transform: rotate(0deg);}\n    100% {transform: rotate(360deg);}\n}\n\n.btn_active{\n    background-color:#337ab7!important;\n    color:#fff!important;\n}\n\n.table{\n    margin-bottom:2px!important;\n}\n</style>'
    };
  });
