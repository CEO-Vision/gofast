!function(){
	var app = angular.module('bonitasoft.ui');

	app.filter('gfTranslateDashboard', function () {
		return function (item) {
			//Retrieve URL parameters
			var params = {};

			if (location.search) {
				var parts = location.search.substring(1).split('&');

				for (var i = 0; i < parts.length; i++) {
					var nv = parts[i].split('=');
					if (!nv[0]) continue;
					params[nv[0]] = nv[1] || true;
				}
			}
			
			//Get the langcode from the URL
			var langcode = params.locale;
			if(typeof langcode == "undefined"){
				langcode = "en";
			}
			//Declare localizations
			var localizations = {
				"en" : {
					"label.process_my_tasks" : "My current tasks",
                                        "label.process_others_tasks" : "Tasks I assigned to others",
                                        "label.process_history" : "History",
                                        "label.in_process" : "In a workflow",
                                        "label.in_space" : "In a space",
				},
				"fr" : {
					"label.process_my_tasks" : "Mes tâches en cours",
                                        "label.process_others_tasks" : "Tâches que j'ai assigné à d'autres",
                                        "label.process_history" : "Historique",
                                        "label.in_process" : "Dans un processus",
                                        "label.in_space" : "Dans un espace",
				},
				"nl" : {
					"label.process_my_tasks" : "Mijn huidige taken",
                                        "label.process_others_tasks" : "Taken die ik aan anderen heb toegewezen",
                                        "label.process_history" : "Geschiedenis",
                                        "label.in_process" : "In een workflow",
                                        "label.in_space" : "In een ruimte",
					
				},
			};
			
			//Return the translated content
			if(typeof localizations[langcode][item] !== "undefined"){
				return localizations[langcode][item];
			}else if(typeof localizations[langcode]["en"] !== "undefined"){
				return localizations[langcode]["en"];
			}else{
				return "Translation not found for key : " + item;
			}
		};
	});
}();