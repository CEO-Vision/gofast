$("document").ready(function(){
	var url = new URL(location.href);
    var title = url.searchParams.get("title");
	var nid = url.searchParams.get("nid");
	jQuery(".mybutton button").click(function(){window.parent.parent.Drupal.gofast_workflows.ceo_vision_js_process_get_available_processes(nid+"`"+title)});
});