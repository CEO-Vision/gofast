(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customGofastTasksInProcessTable', function() {
    return {
      controllerAs: 'ctrl',
      controller: function PbTableCtrl($scope, $http, $sce, $filter) {
     $scope.pagination = [];
     
     
    
     $scope.task_ids = "";
     $scope.$watch("properties.content", function(){
          if(typeof $scope.properties.content == "undefined"){
              return;
          }
         $scope.final_content = [];
         $scope.build_pagination();

         $scope.properties.content.forEach(function(myTask) {
                    myTask.title = myTask.name;
                    myTask.actor = get_initiator_html(myTask);
                    myTask.done = get_deadline_html(myTask);
                    myTask.start_date = myTask.start;
                    myTask.state = myTask.state;
                    
                    if(myTask.state == "ready"){
                        myTask.fa_state = "fa-arrow-right";
                        myTask.state = $filter('gfTranslate')("label.state_ready");
                        myTask.icon = "fa-clock-o";
                        myTask.margin = "3";
                    }else{
                        myTask.fa_state = "fa-check";
                        myTask.state = $filter('gfTranslate')("label.state_done");
                        myTask.icon = "fa-check";
                        myTask.margin = "1";
                    }
        
                    $scope.final_content.push(myTask);
        });
   
     });
        

  this.isArray = Array.isArray;
  
    $scope.build_pagination = function(){
          $scope.$watch("properties.pageCount", function(){
              
          if(typeof $scope.properties.pageCount == "undefined"){
              return;
          }
          $scope.pagination = [];
          var results_count = typeof $scope.properties.pageCount == "object" ? $scope.properties.pageCount.getResponseHeader('Content-Range').replace("0-0/", "") : $scope.properties.pageCount;
          var number_page = results_count / 5;
          
          var i;
          for (i = 0; i < number_page; i++) {
                page_label = i + 1;
                if(i == $scope.properties.page){
                    var btn_class = "btn_active";
                }else{
                    var btn_class = "";
                }
                var my_page_object = {number:i, label:page_label, btn_class:btn_class}
                $scope.pagination.push(my_page_object);
           }
        });
        
  }
  
  
   $scope.change_page = function($event){
       if($scope.properties.page != $event.target.id.replace("page_", "")){
           $scope.properties.content.length = 0
           $scope.task_ids = "";
           $scope.final_content = [];
           $scope.properties.page = $event.target.id.replace("page_", "");
        }
       
   }

  $scope.ceo_vision_js_task_doit = function() {
      var row = $scope.properties.selectedRow;
      var force_assign = "false";
      if(row.assigned_id == 0){
           force_assign = "true";
      }
      window.parent.parent.Drupal.gofast_workflows.ceo_vision_js_task_doit(row.id, row.processDefinititionSub.name+"/"+row.processDefinititionSub.version, "", row.name, force_assign);
  };

  $scope.ceo_vision_js_process_pageflow = function(){
     var row = $scope.properties.selectedRow;
     window.parent.parent.Drupal.gofast_workflows.ceo_vision_js_process_pageflow("bdm", "", row.processHistory.persistenceId,"");

  };
  
    function get_initiator_html_old(myTask){
      //if task is assigned to current user, display initiator picture, else display assigned
    var initiator_string = myTask.assigned_id;
  
      var url = "/api/user/picture?username="+initiator_string;
       $http.get(url).then( 
                   function successCallback(response) {
                        myTask.actor = $sce.trustAsHtml(response.data.content);
                   }    
            ); 
     
  }

  function get_initiator_html(myTask){
         var initiator_string = myTask.assigneeId; 
  
      if(initiator_string == 0){
          initiator_string = $filter('gfTranslate')("label.unassigned");
      }else{
          var url = "/api/user/picture?username="+initiator_string;
           $http.get(url).then( 
                       function successCallback(response) {
                              var label_actor = $filter('gfTranslate')("label.assigned_to");
                              myTask.actor =$sce.trustAsHtml("<div style='clear:both;'>"+label_actor+"  : "+response.data.content+"</div>");
                       }    
                ); 
      }

  }
  
 function get_documents_html_old(myVariable, myTask){
      var documents_string = myVariable.value.replace(/\;/g, ",");
 
      var url = "/api/node/links?nids="+documents_string;
       $http.get(url).then( 
                   function successCallback(response) {
                        myTask.documents = $sce.trustAsHtml(response.data.content);
                   }    
            );  
  }
  

  function get_documents_html(myProcessCurrent, myTask){
      var documents_string = "";
      if(typeof myProcessCurrent.documents != "undefined"){
           myProcessCurrent.documents.forEach(function(nid) {
                documents_string = documents_string + nid +",";
          });
      }else{
          myProcessCurrent.contents.forEach(function(myProcessCurrentContent) {
              if(myProcessCurrentContent.type == "node"){
                  documents_string = documents_string + myProcessCurrentContent.content_value+",";
              }
          });
      }
      var url = "/api/node/links?nids="+documents_string;
       $http.get(url).then( 
                   function successCallback(response) {
                        myTask.documents = $sce.trustAsHtml(response.data.content);
                   }    
            );  
  }
  
  function get_deadline_html(myTask){
    myTask.has_deadline = true;
    if(myTask.done === null || typeof myTask.done == "undefined"){
        myTask.done = " / ";
        myTask.has_deadline = false;
        myTask.deadline_color = "#5bc0de";
        
    }else{
        myTask.deadline_color = "#2ecc71";
    }
      var deadline_html = myTask.done;
    
      return deadline_html;
  }

  this.isClickable = function () {
    return $scope.properties.isBound('selectedRow');
  };

  this.selectRow = function (row) {
    if (this.isClickable()) {
      $scope.properties.selectedRow = row;
    }
  };

  this.isSelected = function(row) {
    return angular.equals(row, $scope.properties.selectedRow);
  };

}
,
      template: '<div class="table-responsive" style="overflow:visible;">\n    <div ng-if="!ctrl.isArray(final_content)" class="loader-autocomplete">&nbsp;</div>\n    <table class="table" ng-class="{\'table-hover\': ctrl.isClickable()}">\n        <thead>\n             <tr>\n                <th>\n                </th>\n            </tr>\n        </thead>\n        \n         <tbody ng-if="ctrl.isArray(final_content)">\n            <tr ng-repeat="row in final_content" ng-click="ctrl.selectRow(row)" ng-class="{\'info\': ctrl.isSelected(row)}">\n                <td>\n                    \n                <div class="task_in_todoliste" style="background-color: #f9f9f9;border: 1px solid #eee;list-style: none;padding: 17px 9px 12px;position: relative;" >\n                    <div class=\'task_in_todoliste\' style=\'padding-left:70px;\'>\n						<span style=\'background-color: {{row.deadline_color}};position: absolute;margin-left: -70px;margin-top: -5px;height: 30px;width: 30px;\'>\n							<i class=\'fa {{row.icon}} fa-2x\' style=\'color:white;margin-top:1px;margin-left:{{row.margin}}px;\'></i>\n					</span>\n                    <div style="float:right;">\n                       <span ng-bind-html="row.actor" class="ng-binding ng-scope card-text actor_container" style="display: inline-block;clear:both;"></span> \n                    </div>\n                    <div style="padding-left:20px;">\n                        <div class="row">\n                            <span style="color:#337ab7;width:25%;white-space: nowrap;overflow:hidden;text-overflow:ellipsis;-o-text-overflow:ellipsis;display: inline-block;" title=\'{{"label.process_title" | gfTranslate}}\'>\n                                <i class="fa {{row.fa_state}}"></i>\n                                <span class="card-title">{{row.state}}</span>\n                            </span>\n                            <span style="color:#337ab7;font-weight: bold;width:28%;white-space: nowrap;overflow:hidden;text-overflow:ellipsis;-o-text-overflow:ellipsis;display: inline-block;">\n                                <i class="fa fa-play"></i>\n                                <span class="card-subtitle mb-2 text-muted">{{row.title | gfTranslate}}</span>\n                            </span>\n							<div class="deadline_box_in_rapide_todoliste" style="max-width:125px;max-height:22px;overflow:hidden;text-overflow:ellipsis;-o-text-overflow:ellipsis;display: inline-block;">\n                                <i class="fa fa-calendar"></i> <span title=\'{{"label.process_start_date" | gfTranslate}}\'>{{row.start|date:"dd/MM/yyyy"}}</span>\n                            </div>\n                            <div class="deadline_box_in_rapide_todoliste" style="font-weight:bold;cursor:pointer;width:125px;text-align:center;px;max-height:22px;overflow:hidden;text-overflow:ellipsis;-o-text-overflow:ellipsis;display: inline-block;">\n                                <i ng-if="row.has_deadline" class="fa fa-check" style="color:{{row.deadline_color}};"></i> <span style="color:{{row.deadline_color}};" title=\'{{"label.process_deadline" | gfTranslate}}\'>{{row.done|date:"dd/MM/yyyy"}}</span>\n                            </div>\n                        </div>\n                    </div>\n                    <div style="clear:both;"></div>\n                </div>\n                </td>\n            </tr>\n        </tbody>\n    </table>\n    <div class="btn-group" style="margin: 0 auto;display: table;">\n        <button page="{{page.number}}" id="page_{{page.number}}" ng-click=\'change_page($event);\' ng-repeat="page in pagination" type="button" class="btn btn-default {{page.btn_class}}" aria-haspopup="true" aria-expanded="false" style="background-color:#fff;color:#337ab7;">\n           {{page.label}}\n        </button>\n    </div>\n</div>\n\n<style>\n.loader-autocomplete{\n    border:3px solid #f3f3f3;\n    border-radius: 50%;\n    border-top: 3px solid #3498db;\n    border-bottom: 3px solid #3498db;\n    width:50px;\n    height:50px;\n    -webkit-animation: spin 2s linear infinite;\n    animation: spin-loader 2s linear infinite;\n    margin: 0 auto;\n\n}\n\n@keyframes spin-loader{\n    0% {transform: rotate(0deg);}\n    100% {transform: rotate(360deg);}\n}\n\n.btn_active{\n    background-color:#337ab7!important;\n    color:#fff!important;\n}\n\n.table{\n    margin-bottom:2px!important;\n}\n</style>'
    };
  });
