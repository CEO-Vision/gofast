package org.mycompany.connector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractGofast_sendmailImpl extends AbstractConnector {

	protected final static String DESTINATAIRE_INPUT_PARAMETER = "destinataire";
	protected final static String SUJET_INPUT_PARAMETER = "sujet";
	protected final static String MESSAGE_INPUT_PARAMETER = "message";
	protected final static String NOTIFIER_AUTEUR_INPUT_PARAMETER = "notifier_auteur";
	protected final static String SUJET_AUTEUR_INPUT_PARAMETER = "sujet_auteur";
	protected final static String MESSAGE_AUTEUR_INPUT_PARAMETER = "message_auteur";

	protected final java.lang.String getDestinataire() {
		return (java.lang.String) getInputParameter(DESTINATAIRE_INPUT_PARAMETER);
	}

	protected final java.lang.String getSujet() {
		return (java.lang.String) getInputParameter(SUJET_INPUT_PARAMETER);
	}

	protected final java.lang.String getMessage() {
		return (java.lang.String) getInputParameter(MESSAGE_INPUT_PARAMETER);
	}

	protected final java.lang.Boolean getNotifier_auteur() {
		return (java.lang.Boolean) getInputParameter(NOTIFIER_AUTEUR_INPUT_PARAMETER);
	}

	protected final java.lang.String getSujet_auteur() {
		return (java.lang.String) getInputParameter(SUJET_AUTEUR_INPUT_PARAMETER);
	}

	protected final java.lang.String getMessage_auteur() {
		return (java.lang.String) getInputParameter(MESSAGE_AUTEUR_INPUT_PARAMETER);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getDestinataire();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("destinataire type is invalid");
		}
		try {
			getSujet();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("sujet type is invalid");
		}
		try {
			getMessage();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("message type is invalid");
		}
		try {
			getNotifier_auteur();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("notifier_auteur type is invalid");
		}
		try {
			getSujet_auteur();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("sujet_auteur type is invalid");
		}
		try {
			getMessage_auteur();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("message_auteur type is invalid");
		}

	}

}
