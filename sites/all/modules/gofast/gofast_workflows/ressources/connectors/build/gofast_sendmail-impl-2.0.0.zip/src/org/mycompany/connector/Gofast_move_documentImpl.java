/**
 * 
 */
package org.mycompany.connector;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.bonitasoft.engine.connector.ConnectorException;

/**
 *The connector execution will follow the steps
 * 1 - setInputParameters() --> the connector receives input parameters values
 * 2 - validateInputParameters() --> the connector can validate input parameters values
 * 3 - connect() --> the connector can establish a connection to a remote server (if necessary)
 * 4 - executeBusinessLogic() --> execute the connector
 * 5 - getOutputParameters() --> output are retrieved from connector
 * 6 - disconnect() --> the connector can close connection to remote server (if any)
 */
public class Gofast_move_documentImpl extends AbstractGofast_move_documentImpl {

	@Override
	protected void executeBusinessLogic() throws ConnectorException{
		//Get access to the connector input parameters
		//getReference_document();
		//getNom_dossier_cible();
		//getNom_espace_collaboratif_cible();
	
		Long processInstanceId = getExecutionContext().getProcessInstanceId();
		

		
		String ref_document = getReference_document();
		String auteur_deplacement = getAuteur_deplacement().toString();
		String nom_dossier_cible = "";	
		try {
			nom_dossier_cible = URLEncoder.encode(getNom_dossier_cible(), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Bloc catch généré automatiquement
			e.printStackTrace();
		}
		
		String nom_espace_collaboratif_cible = "";

		try {
			nom_espace_collaboratif_cible = URLEncoder.encode( getNom_espace_collaboratif_cible(), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Bloc catch généré automatiquement
			e.printStackTrace();
		}
		
		String full_path = "";

		try {
			full_path = URLEncoder.encode( getChemin_complet(), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Bloc catch généré automatiquement
			e.printStackTrace();
		}
		
		String url_encoded_data = "";	
	
		String data = "{\"caseId\" : \""+processInstanceId+"\", \"ref_document\" : \""+ref_document+"\", \"dossier_cible\" : \""+nom_dossier_cible+"\", \"espace_cible\" : \""+nom_espace_collaboratif_cible+"\", \"full_path\" : \""+full_path+"\", \"auteur_deplacement\" : \""+auteur_deplacement+"\" }";

		try {
			url_encoded_data = URLEncoder.encode(data, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Bloc catch généré automatiquement
			e.printStackTrace();
		}
		
		
		String url = "http://localhost/workflow/api/move/document/?data="+url_encoded_data;
    	
    	HttpClient httpClient = new DefaultHttpClient();
		HttpGet getRequest = new HttpGet(url);
		try {
			HttpResponse response = httpClient.execute(getRequest);
		} catch (ClientProtocolException e) {
			// TODO Bloc catch généré automatiquement
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Bloc catch généré automatiquement
			e.printStackTrace();
		}
		
			
			//String ref_document = getReference_document();
			//String nom_dossier_cible = getNom_dossier_cible();
			//String nom_espace_collaboratif_cible = getNom_espace_collaboratif_cible(); 
			//String url_encoded_data = "";	
		
			//String data = "{\"caseId\" : \""+processInstanceId+"\", \"ref_document\" : \""+ref_document+"\", \"dossier_cible\" : \""+nom_dossier_cible+"\", \"espace_cible\" : \""+nom_espace_collaboratif_cible+"\"}";
			
			//url_encoded_data = URLEncoder.encode(data, "UTF-8");
	    	//String url = "http://localhost/workflow/api/move/document/?data="+url_encoded_data;
	    	
	    	//HttpClient httpClient = new DefaultHttpClient();		
			//HttpGet getRequest = new HttpGet(url);			
			//HttpResponse response = httpClient.execute(getRequest);

	
	 }

	@Override
	public void connect() throws ConnectorException{
		//[Optional] Open a connection to remote server
	
	}

	@Override
	public void disconnect() throws ConnectorException{
		//[Optional] Close connection to remote server
	
	}

}
