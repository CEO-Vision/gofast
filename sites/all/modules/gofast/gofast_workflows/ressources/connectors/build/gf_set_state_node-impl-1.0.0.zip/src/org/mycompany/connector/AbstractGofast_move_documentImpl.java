package org.mycompany.connector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractGofast_move_documentImpl extends
		AbstractConnector {

	protected final static String REFERENCE_DOCUMENT_INPUT_PARAMETER = "reference_document";
	protected final static String NOM_DOSSIER_CIBLE_INPUT_PARAMETER = "nom_dossier_cible";
	protected final static String NOM_ESPACE_COLLABORATIF_CIBLE_INPUT_PARAMETER = "nom_espace_collaboratif_cible";
	protected final static String CHEMIN_COMPLET_INPUT_PARAMETER = "chemin_complet";
	protected final static String AUTEUR_DEPLACEMENT_INPUT_PARAMETER = "auteur_deplacement";

	protected final java.lang.String getReference_document() {
		return (java.lang.String) getInputParameter(REFERENCE_DOCUMENT_INPUT_PARAMETER);
	}

	protected final java.lang.String getNom_dossier_cible() {
		return (java.lang.String) getInputParameter(NOM_DOSSIER_CIBLE_INPUT_PARAMETER);
	}

	protected final java.lang.String getNom_espace_collaboratif_cible() {
		return (java.lang.String) getInputParameter(NOM_ESPACE_COLLABORATIF_CIBLE_INPUT_PARAMETER);
	}

	protected final java.lang.String getChemin_complet() {
		return (java.lang.String) getInputParameter(CHEMIN_COMPLET_INPUT_PARAMETER);
	}

	protected final java.lang.Long getAuteur_deplacement() {
		return (java.lang.Long) getInputParameter(AUTEUR_DEPLACEMENT_INPUT_PARAMETER);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getReference_document();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"reference_document type is invalid");
		}
		try {
			getNom_dossier_cible();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"nom_dossier_cible type is invalid");
		}
		try {
			getNom_espace_collaboratif_cible();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"nom_espace_collaboratif_cible type is invalid");
		}
		try {
			getChemin_complet();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"chemin_complet type is invalid");
		}
		try {
			getAuteur_deplacement();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"auteur_deplacement type is invalid");
		}

	}

}
