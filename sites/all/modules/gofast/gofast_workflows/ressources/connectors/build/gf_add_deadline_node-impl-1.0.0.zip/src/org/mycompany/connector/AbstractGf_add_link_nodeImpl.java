package org.mycompany.connector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractGf_add_link_nodeImpl extends AbstractConnector {

	protected final static String NID_INPUT_PARAMETER = "nid";
	protected final static String LINK_INPUT_PARAMETER = "link";
	protected final static String INTERNAL_INPUT_PARAMETER = "internal";
	protected final static String AUTHOR_INPUT_PARAMETER = "author";
	protected final String OUTPUT_OUTPUT_PARAMETER = "output";

	protected final java.lang.String getNid() {
		return (java.lang.String) getInputParameter(NID_INPUT_PARAMETER);
	}

	protected final java.lang.String getLink() {
		return (java.lang.String) getInputParameter(LINK_INPUT_PARAMETER);
	}

	protected final java.lang.Boolean getInternal() {
		return (java.lang.Boolean) getInputParameter(INTERNAL_INPUT_PARAMETER);
	}

	protected final java.lang.String getAuthor() {
		return (java.lang.String) getInputParameter(AUTHOR_INPUT_PARAMETER);
	}

	protected final void setOutput(java.lang.String output) {
		setOutputParameter(OUTPUT_OUTPUT_PARAMETER, output);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getNid();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("nid type is invalid");
		}
		try {
			getLink();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("link type is invalid");
		}
		try {
			getInternal();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("internal type is invalid");
		}
		try {
			getAuthor();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("author type is invalid");
		}

	}

}
