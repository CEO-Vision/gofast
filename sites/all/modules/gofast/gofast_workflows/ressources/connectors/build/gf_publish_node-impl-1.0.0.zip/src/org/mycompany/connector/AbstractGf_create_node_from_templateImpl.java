package org.mycompany.connector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractGf_create_node_from_templateImpl extends AbstractConnector {

	protected final static String TITRE_INPUT_PARAMETER = "titre";
	protected final static String NID_INPUT_PARAMETER = "nid";
	protected final static String TYPE_INPUT_PARAMETER = "type";
	protected final static String LOCATIONS_INPUT_PARAMETER = "locations";
	protected final static String AUTHOR_INPUT_PARAMETER = "author";
	protected final static String KEEP_TAGS_INPUT_PARAMETER = "keep_tags";
	protected final String OUTPUT_OUTPUT_PARAMETER = "output";

	protected final java.lang.String getTitre() {
		return (java.lang.String) getInputParameter(TITRE_INPUT_PARAMETER);
	}

	protected final java.lang.String getNid() {
		return (java.lang.String) getInputParameter(NID_INPUT_PARAMETER);
	}

	protected final java.lang.String getType() {
		return (java.lang.String) getInputParameter(TYPE_INPUT_PARAMETER);
	}

	protected final java.util.List getLocations() {
		return (java.util.List) getInputParameter(LOCATIONS_INPUT_PARAMETER);
	}

	protected final java.lang.String getAuthor() {
		return (java.lang.String) getInputParameter(AUTHOR_INPUT_PARAMETER);
	}

	protected final java.lang.Boolean getKeep_tags() {
		return (java.lang.Boolean) getInputParameter(KEEP_TAGS_INPUT_PARAMETER);
	}

	protected final void setOutput(java.lang.String output) {
		setOutputParameter(OUTPUT_OUTPUT_PARAMETER, output);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getTitre();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("titre type is invalid");
		}
		try {
			getNid();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("nid type is invalid");
		}
		try {
			getType();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("type type is invalid");
		}
		try {
			getLocations();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("locations type is invalid");
		}
		try {
			getAuthor();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("author type is invalid");
		}
		try {
			getKeep_tags();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("keep_tags type is invalid");
		}

	}

}
