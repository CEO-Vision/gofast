package org.mycompany.connector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractWebservice_gofastImpl extends AbstractConnector {

	protected final String RETURNCODE_OUTPUT_PARAMETER = "returncode";

	protected final void setReturncode(java.lang.String returncode) {
		setOutputParameter(RETURNCODE_OUTPUT_PARAMETER, returncode);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {

	}

}
