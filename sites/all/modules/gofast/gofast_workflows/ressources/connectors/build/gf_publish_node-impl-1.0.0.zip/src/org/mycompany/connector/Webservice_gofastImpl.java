/**
 * 
 */
package org.mycompany.connector;

import org.bonitasoft.engine.connector.ConnectorException;


import org.apache.http.client.HttpClient;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
//import org.apache.http.protocol.HttpContext;
import org.apache.http.impl.client.DefaultHttpClient;
import java.net.URLEncoder;



/**
 *The connector execution will follow the steps
 * 1 - setInputParameters() --> the connector receives input parameters values
 * 2 - validateInputParameters() --> the connector can validate input parameters values
 * 3 - connect() --> the connector can establish a connection to a remote server (if necessary)
 * 4 - executeBusinessLogic() --> execute the connector
 * 5 - getOutputParameters() --> output are retrieved from connector
 * 6 - disconnect() --> the connector can close connection to remote server (if any)
 */
public class Webservice_gofastImpl extends AbstractWebservice_gofastImpl {

	
	@Override
	protected void executeBusinessLogic() throws ConnectorException{
		//Get access to the connector input parameters
		//getUrl_api();
		//getHostname();
		//getData();
	
		//TODO execute your business logic here 
		Integer processInstanceId = 5;
		Integer Notify_author = 0;
		String validateur = "sjeandroz";
		String message = "coucou";
		String subject = "email subject";
		String url_encoded_data = "";
		

//		def data = builder (
//				'"caseId"' : '"'+processInstanceId+'"',
//				'"login"' : '"'+validateur+'"',
//				'"message"' : '',
//				'"subject"' : '"Tache crée"'
//			)
		
	    String data = "{\"caseId\" : \""+processInstanceId+"\",\"login\" : \""+validateur+"\",\"message\" : \""+message+"\",\"subject\" : \""+subject+"\", \"notify_author\":\""+Notify_author+"\"}";
	    //URLEncoder URLEncoder = new URLEncoder;
	    try{
	    	url_encoded_data = URLEncoder.encode(data, "UTF-8");
	    }catch (Exception e) {
	    	
		}
		
		
		String url = "http://dev2.ceo-vision.com/workflow/api/sendmail/?data="+url_encoded_data;
		
		
		HttpClient httpClient = new DefaultHttpClient();
		//HttpContext httpContext;
		HttpGet getRequest = new HttpGet(url);
		try{
			//HttpResponse response = httpClient.execute(getRequest, httpContext);
			HttpResponse response = httpClient.execute(getRequest);
		}catch (Exception e) {
			
		}
		
		setReturncode("");
		//String return_string = "";
		//setReturn(return_string);
		//WARNING : Set the output of the connector execution. If outputs are not set, connector fails
		//setReturn(return);
	
	 }

	@Override
	public void connect() throws ConnectorException{
		//[Optional] Open a connection to remote server
	
	}

	@Override
	public void disconnect() throws ConnectorException{
		//[Optional] Close connection to remote server
	
	}
	

}
