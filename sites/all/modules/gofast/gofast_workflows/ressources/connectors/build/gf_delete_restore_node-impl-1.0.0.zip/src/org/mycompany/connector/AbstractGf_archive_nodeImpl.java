package org.mycompany.connector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractGf_archive_nodeImpl extends AbstractConnector {

	protected final static String AUTHOR_INPUT_PARAMETER = "author";
	protected final static String NID_INPUT_PARAMETER = "nid";
	protected final static String UNARCHIVE_INPUT_PARAMETER = "unarchive";
	protected final String OUTPUT_OUTPUT_PARAMETER = "output";

	protected final java.lang.String getAuthor() {
		return (java.lang.String) getInputParameter(AUTHOR_INPUT_PARAMETER);
	}

	protected final java.lang.String getNid() {
		return (java.lang.String) getInputParameter(NID_INPUT_PARAMETER);
	}

	protected final java.lang.Boolean getUnarchive() {
		return (java.lang.Boolean) getInputParameter(UNARCHIVE_INPUT_PARAMETER);
	}

	protected final void setOutput(java.lang.String output) {
		setOutputParameter(OUTPUT_OUTPUT_PARAMETER, output);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getAuthor();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("author type is invalid");
		}
		try {
			getNid();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("nid type is invalid");
		}
		try {
			getUnarchive();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("unarchive type is invalid");
		}

	}

}
