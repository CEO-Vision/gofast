package org.mycompany.connector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractTest_assign_userImpl extends AbstractConnector {

	@Override
	public void validateInputParameters() throws ConnectorValidationException {

	}

}
