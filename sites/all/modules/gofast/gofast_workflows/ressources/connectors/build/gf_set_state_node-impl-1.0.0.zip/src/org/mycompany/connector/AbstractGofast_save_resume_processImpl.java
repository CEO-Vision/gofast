package org.mycompany.connector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractGofast_save_resume_processImpl extends
		AbstractConnector {

	protected final static String GROUPE_DESTINATION_INPUT_PARAMETER = "groupe_destination";
	protected final static String AUTEUR_INPUT_PARAMETER = "auteur";
	protected final static String TITRE_RESUME_INPUT_PARAMETER = "titre_resume";

	protected final java.lang.String getGroupe_destination() {
		return (java.lang.String) getInputParameter(GROUPE_DESTINATION_INPUT_PARAMETER);
	}

	protected final java.lang.String getAuteur() {
		return (java.lang.String) getInputParameter(AUTEUR_INPUT_PARAMETER);
	}

	protected final java.lang.String getTitre_resume() {
		return (java.lang.String) getInputParameter(TITRE_RESUME_INPUT_PARAMETER);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getGroupe_destination();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"groupe_destination type is invalid");
		}
		try {
			getAuteur();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("auteur type is invalid");
		}
		try {
			getTitre_resume();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"titre_resume type is invalid");
		}

	}

}
