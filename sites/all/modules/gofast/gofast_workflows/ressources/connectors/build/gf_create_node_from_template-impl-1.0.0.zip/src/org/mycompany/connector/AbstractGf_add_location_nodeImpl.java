package org.mycompany.connector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractGf_add_location_nodeImpl extends AbstractConnector {

	protected final static String AUTHOR_INPUT_PARAMETER = "author";
	protected final static String NID_INPUT_PARAMETER = "nid";
	protected final static String LOCATIONS_INPUT_PARAMETER = "locations";
	protected final static String DELETE_INPUT_PARAMETER = "delete";
	protected final String OUTPUT_OUTPUT_PARAMETER = "output";

	protected final java.lang.String getAuthor() {
		return (java.lang.String) getInputParameter(AUTHOR_INPUT_PARAMETER);
	}

	protected final java.lang.String getNid() {
		return (java.lang.String) getInputParameter(NID_INPUT_PARAMETER);
	}

	protected final java.util.List getLocations() {
		return (java.util.List) getInputParameter(LOCATIONS_INPUT_PARAMETER);
	}

	protected final java.lang.Boolean getDelete() {
		return (java.lang.Boolean) getInputParameter(DELETE_INPUT_PARAMETER);
	}

	protected final void setOutput(java.lang.String output) {
		setOutputParameter(OUTPUT_OUTPUT_PARAMETER, output);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getAuthor();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("author type is invalid");
		}
		try {
			getNid();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("nid type is invalid");
		}
		try {
			getLocations();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("locations type is invalid");
		}
		try {
			getDelete();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("delete type is invalid");
		}

	}

}
