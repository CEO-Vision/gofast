package org.mycompany.connector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractGf_add_deadline_nodeImpl extends AbstractConnector {

	protected final static String AUTHOR_INPUT_PARAMETER = "author";
	protected final static String NID_INPUT_PARAMETER = "nid";
	protected final static String DEADLINE_INPUT_PARAMETER = "deadline";
	protected final String OUTPUT_OUTPUT_PARAMETER = "output";

	protected final java.lang.String getAuthor() {
		return (java.lang.String) getInputParameter(AUTHOR_INPUT_PARAMETER);
	}

	protected final java.lang.String getNid() {
		return (java.lang.String) getInputParameter(NID_INPUT_PARAMETER);
	}

	protected final java.lang.String getDeadline() {
		return (java.lang.String) getInputParameter(DEADLINE_INPUT_PARAMETER);
	}

	protected final void setOutput(java.lang.String output) {
		setOutputParameter(OUTPUT_OUTPUT_PARAMETER, output);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getAuthor();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("author type is invalid");
		}
		try {
			getNid();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("nid type is invalid");
		}
		try {
			getDeadline();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("deadline type is invalid");
		}

	}

}
