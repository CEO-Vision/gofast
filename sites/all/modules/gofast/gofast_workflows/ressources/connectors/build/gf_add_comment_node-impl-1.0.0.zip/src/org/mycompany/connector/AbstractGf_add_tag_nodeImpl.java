package org.mycompany.connector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractGf_add_tag_nodeImpl extends AbstractConnector {

	protected final static String NID_INPUT_PARAMETER = "nid";
	protected final static String TAGS_INPUT_PARAMETER = "tags";
	protected final static String AUTHOR_INPUT_PARAMETER = "author";
	protected final String OUTPUT_OUTPUT_PARAMETER = "output";

	protected final java.lang.String getNid() {
		return (java.lang.String) getInputParameter(NID_INPUT_PARAMETER);
	}

	protected final java.lang.String getTags() {
		return (java.lang.String) getInputParameter(TAGS_INPUT_PARAMETER);
	}

	protected final java.lang.String getAuthor() {
		return (java.lang.String) getInputParameter(AUTHOR_INPUT_PARAMETER);
	}

	protected final void setOutput(java.lang.String output) {
		setOutputParameter(OUTPUT_OUTPUT_PARAMETER, output);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getNid();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("nid type is invalid");
		}
		try {
			getTags();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("tags type is invalid");
		}
		try {
			getAuthor();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("author type is invalid");
		}

	}

}
