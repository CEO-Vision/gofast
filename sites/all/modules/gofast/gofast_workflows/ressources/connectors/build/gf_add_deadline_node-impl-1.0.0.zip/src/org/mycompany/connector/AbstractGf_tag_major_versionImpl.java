package org.mycompany.connector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractGf_tag_major_versionImpl extends AbstractConnector {

	protected final static String AUTHOR_INPUT_PARAMETER = "author";
	protected final static String NID_INPUT_PARAMETER = "nid";
	protected final static String COMMENT_MESSAGE_INPUT_PARAMETER = "comment_message";
	protected final static String CREATE_COMMENT_INPUT_PARAMETER = "create_comment";
	protected final String OUTPUT_OUTPUT_PARAMETER = "output";

	protected final java.lang.String getAuthor() {
		return (java.lang.String) getInputParameter(AUTHOR_INPUT_PARAMETER);
	}

	protected final java.lang.String getNid() {
		return (java.lang.String) getInputParameter(NID_INPUT_PARAMETER);
	}

	protected final java.lang.String getComment_message() {
		return (java.lang.String) getInputParameter(COMMENT_MESSAGE_INPUT_PARAMETER);
	}

	protected final java.lang.Boolean getCreate_comment() {
		return (java.lang.Boolean) getInputParameter(CREATE_COMMENT_INPUT_PARAMETER);
	}

	protected final void setOutput(java.lang.String output) {
		setOutputParameter(OUTPUT_OUTPUT_PARAMETER, output);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getAuthor();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("author type is invalid");
		}
		try {
			getNid();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("nid type is invalid");
		}
		try {
			getComment_message();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("comment_message type is invalid");
		}
		try {
			getCreate_comment();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("create_comment type is invalid");
		}

	}

}
