package org.mycompany.connector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractGofast_save_historyImpl extends AbstractConnector {

	protected final static String HISTORY_VARIABLE_NAME_INPUT_PARAMETER = "history_variable_name";
	protected final static String CLOSE_INPUT_PARAMETER = "close";

	protected final java.lang.String getHistory_variable_name() {
		return (java.lang.String) getInputParameter(HISTORY_VARIABLE_NAME_INPUT_PARAMETER);
	}

	protected final java.lang.Boolean getClose() {
		return (java.lang.Boolean) getInputParameter(CLOSE_INPUT_PARAMETER);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getHistory_variable_name();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"history_variable_name type is invalid");
		}
		try {
			getClose();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("close type is invalid");
		}

	}

}
