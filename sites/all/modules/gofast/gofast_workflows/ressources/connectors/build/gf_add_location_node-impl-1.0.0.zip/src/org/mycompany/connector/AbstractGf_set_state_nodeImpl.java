package org.mycompany.connector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractGf_set_state_nodeImpl extends AbstractConnector {

	protected final static String NID_INPUT_PARAMETER = "nid";
	protected final static String AUTHOR_INPUT_PARAMETER = "author";
	protected final static String ETAT_INPUT_PARAMETER = "etat";
	protected final String OUTPUT_OUTPUT_PARAMETER = "output";

	protected final java.lang.String getNid() {
		return (java.lang.String) getInputParameter(NID_INPUT_PARAMETER);
	}

	protected final java.lang.String getAuthor() {
		return (java.lang.String) getInputParameter(AUTHOR_INPUT_PARAMETER);
	}

	protected final java.lang.String getEtat() {
		return (java.lang.String) getInputParameter(ETAT_INPUT_PARAMETER);
	}

	protected final void setOutput(java.lang.String output) {
		setOutputParameter(OUTPUT_OUTPUT_PARAMETER, output);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getNid();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("nid type is invalid");
		}
		try {
			getAuthor();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("author type is invalid");
		}
		try {
			getEtat();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("etat type is invalid");
		}

	}

}
