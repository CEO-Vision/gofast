package org.mycompany.connector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractGf_add_comment_nodeImpl extends AbstractConnector {

	protected final static String AUTHOR_INPUT_PARAMETER = "author";
	protected final static String NID_INPUT_PARAMETER = "nid";
	protected final static String SUBJECT_INPUT_PARAMETER = "subject";
	protected final static String BODY_INPUT_PARAMETER = "body";
	protected final static String IS_PRIVATE_INPUT_PARAMETER = "is_private";
	protected final static String IS_ANNOTATION_INPUT_PARAMETER = "is_annotation";
	protected final String OUTPUT_OUTPUT_PARAMETER = "output";

	protected final java.lang.String getAuthor() {
		return (java.lang.String) getInputParameter(AUTHOR_INPUT_PARAMETER);
	}

	protected final java.lang.String getNid() {
		return (java.lang.String) getInputParameter(NID_INPUT_PARAMETER);
	}

	protected final java.lang.String getSubject() {
		return (java.lang.String) getInputParameter(SUBJECT_INPUT_PARAMETER);
	}

	protected final java.lang.String getBody() {
		return (java.lang.String) getInputParameter(BODY_INPUT_PARAMETER);
	}

	protected final java.lang.Boolean getIs_private() {
		return (java.lang.Boolean) getInputParameter(IS_PRIVATE_INPUT_PARAMETER);
	}

	protected final java.lang.Boolean getIs_annotation() {
		return (java.lang.Boolean) getInputParameter(IS_ANNOTATION_INPUT_PARAMETER);
	}

	protected final void setOutput(java.lang.String output) {
		setOutputParameter(OUTPUT_OUTPUT_PARAMETER, output);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getAuthor();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("author type is invalid");
		}
		try {
			getNid();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("nid type is invalid");
		}
		try {
			getSubject();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("subject type is invalid");
		}
		try {
			getBody();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("body type is invalid");
		}
		try {
			getIs_private();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("is_private type is invalid");
		}
		try {
			getIs_annotation();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("is_annotation type is invalid");
		}

	}

}
